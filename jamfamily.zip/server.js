/**
 * JamFamily SHOP — Backend Server v4.0
 * 10 new features: partial payments, PDF/bulk export, due dates,
 * SMS templates, quick presets, stock count, multilang, logo upload,
 * payment method tracking, calendar view
 */
const express = require('express');
const fs      = require('fs');
const path    = require('path');
const cors    = require('cors');
const multer  = require('multer');

const app    = express();
const PORT   = process.env.PORT || 3000;
const DATA   = path.join(__dirname, 'data');
const UPLOAD = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(UPLOAD)) fs.mkdirSync(UPLOAD, { recursive: true });

// ── MULTER ──
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD),
  filename:    (req, file, cb) => {
    const ext  = path.extname(file.originalname).toLowerCase();
    cb(null, file.fieldname + '_' + Date.now() + '_' + Math.random().toString(36).slice(2,7) + ext);
  }
});
const imgFilter = (req, file, cb) => {
  ['.jpg','.jpeg','.png','.gif','.webp'].includes(path.extname(file.originalname).toLowerCase())
    ? cb(null, true) : cb(new Error('Image files only'), false);
};
const upload = multer({ storage, fileFilter: imgFilter, limits: { fileSize: 5*1024*1024 } });

app.use(cors()); app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── DB ──
function readDB(f) { try { return JSON.parse(fs.readFileSync(path.join(DATA,f),'utf8')); } catch { return f.endsWith('settings.json')?{}:[]; } }
function writeDB(f,d) { fs.writeFileSync(path.join(DATA,f), JSON.stringify(d,null,2)); }
function getS()  { return readDB('settings.json'); }
function saveS(s){ writeDB('settings.json',s); }

// ── LOG ──
function addLog(action, details, by='system') {
  const logs=readDB('logs.json'); const s=getS();
  logs.push({ id:s.nextLogId++, action, details, by, dateISO:new Date().toISOString(), date:new Date().toLocaleDateString('en-PH'), time:new Date().toLocaleTimeString('en-PH') });
  if(logs.length>500) logs.splice(0,logs.length-500);
  writeDB('logs.json',logs); saveS(s);
}

// ── OVERDUE CHECK ──
function checkOverdue() {
  const utang=readDB('utang.json'); const s=getS();
  const days=s.overduedays||7; const cutoff=new Date(Date.now()-days*86400000);
  const notifs=readDB('notifications.json');
  const notified=new Set(notifs.filter(n=>n.type==='overdue').map(n=>n.utangId));
  let added=0;
  utang.forEach(u => {
    if(u.status==='pending' && !notified.has(u.id)) {
      const created=new Date(u.dateISO||u.date);
      if(created<cutoff) {
        notifs.push({ id:Date.now()+added++, type:'overdue', utangId:u.id, name:u.name, amount:u.amount, account:u.account, daysOld:Math.floor((Date.now()-created)/86400000), read:false, dateISO:new Date().toISOString() });
        notified.add(u.id);
      }
    }
  });
  if(added>0) writeDB('notifications.json',notifs);
  // due-date notifications
  const dueNotifs=[];
  utang.filter(u=>u.status==='pending'&&u.dueDate).forEach(u=>{
    const due=new Date(u.dueDate); const daysLeft=Math.ceil((due-Date.now())/86400000);
    if(daysLeft<=2&&daysLeft>=-7) {
      const key='due_'+u.id;
      if(!notifs.some(n=>n.utangId===u.id&&n.type==='due')) {
        dueNotifs.push({ id:Date.now()+added++, type:'due', utangId:u.id, name:u.name, amount:u.amount, account:u.account, daysLeft, read:false, dateISO:new Date().toISOString() });
      }
    }
  });
  if(dueNotifs.length) { notifs.push(...dueNotifs); writeDB('notifications.json',notifs); }
  return notifs.filter(n=>!n.read);
}

// ── UPLOAD ──
app.post('/api/upload', upload.single('photo'), (req,res) => {
  if(!req.file) return res.status(400).json({error:'No file'});
  res.json({ success:true, url:'/uploads/'+req.file.filename });
});
app.post('/api/upload/logo', upload.single('logo'), (req,res) => {
  if(!req.file) return res.status(400).json({error:'No file'});
  const url='/uploads/'+req.file.filename;
  saveS({...getS(), logoUrl:url });
  res.json({ success:true, url });
});
function delPhoto(u) {
  if(!u||!u.startsWith('/uploads/')) return;
  try { if(fs.existsSync(path.join(__dirname,'public',u))) fs.unlinkSync(path.join(__dirname,'public',u)); } catch {}
}

// ── AUTH ──
app.post('/api/login', (req,res) => {
  const {username,password}=req.body;
  const user=readDB('users.json').find(u=>u.username===username&&u.password===password);
  if(!user) return res.status(401).json({error:'Wrong username or password'});
  addLog('LOGIN',`"${username}" logged in`,username);
  const {password:_p,...safe}=user;
  res.json({success:true,user:safe});
});
app.put('/api/users/:id/password', (req,res) => {
  const {oldPassword,newPassword}=req.body;
  const users=readDB('users.json');
  const idx=users.findIndex(u=>u.id===parseInt(req.params.id));
  if(idx===-1) return res.status(404).json({error:'User not found'});
  if(users[idx].password!==oldPassword) return res.status(401).json({error:'Current password is wrong'});
  if(!newPassword||newPassword.length<4) return res.status(400).json({error:'Min 4 characters'});
  users[idx].password=newPassword;
  writeDB('users.json',users);
  addLog('PASSWORD_CHANGE',`"${users[idx].username}" changed password`,users[idx].username);
  res.json({success:true});
});

// ── ITEMS ──
app.get('/api/items', (req,res) => {
  let items=readDB('items.json');
  const {category,stock,search}=req.query;
  if(category) items=items.filter(i=>i.category===category);
  if(stock)    items=items.filter(i=>i.stock===stock);
  if(search)   items=items.filter(i=>i.name.toLowerCase().includes(search.toLowerCase()));
  res.json(items);
});
app.post('/api/items', (req,res) => {
  const items=readDB('items.json'); const s=getS();
  const item={ id:s.nextItemId++, sold:0, photo:'', stockCount:null, lowStockAlert:5, ...req.body };
  items.push(item); writeDB('items.json',items); saveS(s);
  addLog('ITEM_ADD',`Added "${item.name}" ₱${item.price}`,req.body.by||'admin');
  res.json(item);
});
app.put('/api/items/:id', (req,res) => {
  const items=readDB('items.json');
  const idx=items.findIndex(i=>i.id===parseInt(req.params.id));
  if(idx===-1) return res.status(404).json({error:'Not found'});
  if(req.body.photo&&req.body.photo!==items[idx].photo) delPhoto(items[idx].photo);
  items[idx]={...items[idx],...req.body};
  writeDB('items.json',items);
  addLog('ITEM_UPDATE',`Updated "${items[idx].name}"`,req.body.by||'admin');
  res.json(items[idx]);
});
app.delete('/api/items/:id', (req,res) => {
  let items=readDB('items.json');
  const item=items.find(i=>i.id===parseInt(req.params.id));
  if(item){ delPhoto(item.photo); addLog('ITEM_DELETE',`Deleted "${item.name}"`,req.query.by||'admin'); }
  writeDB('items.json',items.filter(i=>i.id!==parseInt(req.params.id)));
  res.json({success:true});
});

// ── UTANG ──
app.get('/api/utang', (req,res) => {
  let list=readDB('utang.json');
  const {account,status,search,date}=req.query;
  if(account) list=list.filter(u=>u.account===account||u.by===account);
  if(status)  list=list.filter(u=>u.status===status);
  if(search)  list=list.filter(u=>u.name.toLowerCase().includes(search.toLowerCase())||(u.item||'').toLowerCase().includes(search.toLowerCase()));
  if(date)    list=list.filter(u=>u.date===date||(u.dateISO&&u.dateISO.startsWith(date)));
  res.json(list.reverse());
});
app.post('/api/utang', (req,res) => {
  const utang=readDB('utang.json'); const s=getS();
  const record={ id:s.nextUtangId++, date:new Date().toLocaleDateString('en-PH'), dateISO:new Date().toISOString(), status:'pending', history:[], paidAmount:0, paymentMethod:'', ...req.body };
  utang.push(record); writeDB('utang.json',utang); saveS(s);
  // reduce stock counts
  if(record.items) {
    const items=readDB('items.json');
    record.items.forEach(ri => {
      const idx=items.findIndex(i=>i.id===ri.id);
      if(idx!==-1&&items[idx].stockCount!==null&&items[idx].stockCount!==undefined) {
        items[idx].stockCount=Math.max(0,(items[idx].stockCount||0)-ri.qty);
        if(items[idx].stockCount===0) items[idx].stock='out';
      }
    });
    writeDB('items.json',items);
  }
  addLog('UTANG_ADD',`Utang ni "${record.name}" — ₱${record.amount} (${record.account})`,record.by||'admin');
  res.json(record);
});
app.put('/api/utang/:id', (req,res) => {
  const utang=readDB('utang.json');
  const idx=utang.findIndex(u=>u.id===parseInt(req.params.id));
  if(idx===-1) return res.status(404).json({error:'Not found'});
  const old={...utang[idx]};
  if(req.body.status&&req.body.status!==old.status) {
    if(!utang[idx].history) utang[idx].history=[];
    utang[idx].history.push({ from:old.status, to:req.body.status, note:req.body.paymentNote||'', method:req.body.paymentMethod||'', by:req.body.changedBy||'admin', dateISO:new Date().toISOString(), date:new Date().toLocaleDateString('en-PH'), time:new Date().toLocaleTimeString('en-PH') });
    addLog('UTANG_STATUS',`"${old.name}": ${old.status}→${req.body.status}${req.body.paymentNote?' ('+req.body.paymentNote+')':''}`,req.body.changedBy||'admin');
    if(req.body.status==='paid') {
      const notifs=readDB('notifications.json');
      writeDB('notifications.json',notifs.filter(n=>n.utangId!==utang[idx].id));
    }
  }
  // partial payment recording
  if(req.body.partialAmount) {
    const payments=readDB('payments.json'); const s=getS();
    const amt=parseFloat(req.body.partialAmount);
    payments.push({ id:s.nextPaymentId++, utangId:utang[idx].id, name:utang[idx].name, amount:amt, method:req.body.paymentMethod||'Cash', note:req.body.paymentNote||'', by:req.body.changedBy||'admin', dateISO:new Date().toISOString(), date:new Date().toLocaleDateString('en-PH') });
    writeDB('payments.json',payments); saveS(s);
    utang[idx].paidAmount=(utang[idx].paidAmount||0)+amt;
    if(utang[idx].paidAmount>=utang[idx].amount) { utang[idx].status='paid'; req.body.status='paid'; }
    addLog('PARTIAL_PAYMENT',`"${utang[idx].name}" partial ₱${amt} via ${req.body.paymentMethod||'Cash'}`,req.body.changedBy||'admin');
  }
  delete req.body.paymentNote; delete req.body.changedBy; delete req.body.partialAmount;
  utang[idx]={...utang[idx],...req.body};
  writeDB('utang.json',utang);
  res.json(utang[idx]);
});
app.delete('/api/utang/:id', (req,res) => {
  const utang=readDB('utang.json');
  const r=utang.find(u=>u.id===parseInt(req.params.id));
  if(r) addLog('UTANG_DELETE',`Deleted utang ni "${r.name}" ₱${r.amount}`,'admin');
  writeDB('utang.json',utang.filter(u=>u.id!==parseInt(req.params.id)));
  res.json({success:true});
});
app.put('/api/utang/person/:name/paid', (req,res) => {
  const utang=readDB('utang.json');
  const note=req.body.paymentNote||''; const by=req.body.changedBy||'admin'; const method=req.body.paymentMethod||'Cash';
  let count=0;
  utang.forEach(u => {
    if(u.name===req.params.name&&u.status==='pending') {
      if(!u.history) u.history=[];
      u.history.push({from:'pending',to:'paid',note,method,by,dateISO:new Date().toISOString(),date:new Date().toLocaleDateString('en-PH'),time:new Date().toLocaleTimeString('en-PH')});
      u.status='paid'; count++;
    }
  });
  writeDB('utang.json',utang);
  if(count) addLog('UTANG_BULK_PAID',`Bulk paid ${count} records ni "${req.params.name}"${note?' ('+note+')':''}`,by);
  res.json({success:true,count});
});

// ── PAYMENTS (partial) ──
app.get('/api/payments', (req,res) => {
  let p=readDB('payments.json');
  const {utangId}=req.query;
  if(utangId) p=p.filter(x=>x.utangId===parseInt(utangId));
  res.json(p);
});

// ── USERS ──
app.get('/api/users', (req,res) => res.json(readDB('users.json').map(({password:_p,...u})=>u)));
app.post('/api/users', (req,res) => {
  const users=readDB('users.json'); const s=getS();
  if(users.find(u=>u.username===req.body.username)) return res.status(400).json({error:'Username already exists'});
  const user={id:s.nextUserId++,createdAt:new Date().toLocaleDateString('en-PH'),...req.body};
  users.push(user); writeDB('users.json',users); saveS(s);
  addLog('USER_CREATE',`Created "${user.username}" (${user.role})`,'admin');
  const {password:_p,...safe}=user;
  res.json(safe);
});
app.delete('/api/users/:id', (req,res) => {
  const users=readDB('users.json');
  const u=users.find(u=>u.id===parseInt(req.params.id));
  if(u) addLog('USER_DELETE',`Deleted "${u.username}"`,'admin');
  writeDB('users.json',users.filter(u=>u.id!==parseInt(req.params.id)));
  res.json({success:true});
});

// ── SETTINGS ──
app.get('/api/settings', (req,res) => {
  const s=getS();
  const {nextItemId:_a,nextUserId:_b,nextUtangId:_c,nextLogId:_d,nextPaymentId:_e,nextPresetId:_f,...pub}=s;
  res.json(pub);
});
app.put('/api/settings', (req,res) => { saveS({...getS(),...req.body}); res.json({success:true}); });

// ── PRESETS (quick add combos) ──
app.get('/api/presets', (req,res) => res.json(readDB('presets.json')));
app.post('/api/presets', (req,res) => {
  const presets=readDB('presets.json'); const s=getS();
  const preset={id:s.nextPresetId++,createdAt:new Date().toLocaleDateString('en-PH'),...req.body};
  presets.push(preset); writeDB('presets.json',presets); saveS(s);
  addLog('PRESET_ADD',`Preset "${preset.name}" saved`,'admin');
  res.json(preset);
});
app.delete('/api/presets/:id', (req,res) => {
  writeDB('presets.json',readDB('presets.json').filter(p=>p.id!==parseInt(req.params.id)));
  res.json({success:true});
});

// ── ANALYTICS ──
app.get('/api/analytics', (req,res) => {
  const items=readDB('items.json'); const utang=readDB('utang.json'); const users=readDB('users.json');
  const payments=readDB('payments.json');
  const months={};
  for(let i=5;i>=0;i--){ const d=new Date(); d.setMonth(d.getMonth()-i); const k=d.toLocaleDateString('en-PH',{month:'short',year:'numeric'}); months[k]={month:k,total:0,paid:0,pending:0,count:0}; }
  utang.forEach(u=>{ const d=new Date(u.dateISO||u.date); const k=d.toLocaleDateString('en-PH',{month:'short',year:'numeric'}); if(months[k]){months[k].total+=Number(u.amount);months[k].count++;if(u.status==='paid')months[k].paid+=Number(u.amount);else months[k].pending+=Number(u.amount);} });
  const debtors={};
  utang.filter(u=>u.status==='pending').forEach(u=>{ if(!debtors[u.name])debtors[u.name]=0; debtors[u.name]+=Number(u.amount); });
  const topDebtors=Object.entries(debtors).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([name,amount])=>({name,amount}));
  const itemFreq={};
  utang.forEach(u=>{ if(u.items)u.items.forEach(it=>{ if(!itemFreq[it.name])itemFreq[it.name]={name:it.name,emoji:it.emoji,count:0,revenue:0}; itemFreq[it.name].count+=it.qty||1; itemFreq[it.name].revenue+=Number(it.sub||0); }); });
  const topItems=Object.values(itemFreq).sort((a,b)=>b.count-a.count).slice(0,5);
  const acBreakdown=users.map(u=>{ const myU=utang.filter(t=>t.account===u.username); const pending=myU.filter(t=>t.status==='pending').reduce((a,t)=>a+Number(t.amount),0); const paid=myU.filter(t=>t.status==='paid').reduce((a,t)=>a+Number(t.amount),0); return{username:u.username,role:u.role,records:myU.length,pending,paid}; });
  // payment method breakdown
  const methodBreak={};
  payments.forEach(p=>{ if(!methodBreak[p.method])methodBreak[p.method]=0; methodBreak[p.method]+=p.amount; });
  utang.filter(u=>u.status==='paid').forEach(u=>{ const m=u.paymentMethod||'Unknown'; if(!methodBreak[m])methodBreak[m]=0; });
  const paymentMethods=Object.entries(methodBreak).map(([method,amount])=>({method,amount})).sort((a,b)=>b.amount-a.amount);
  // calendar data (activity by date last 35 days)
  const calData={};
  const cutoff35=new Date(Date.now()-35*86400000);
  utang.forEach(u=>{ const d=new Date(u.dateISO||u.date); if(d>=cutoff35){const k=d.toISOString().split('T')[0];if(!calData[k])calData[k]={date:k,count:0,amount:0};calData[k].count++;calData[k].amount+=Number(u.amount);} });
  const totalUtang=utang.reduce((a,u)=>a+Number(u.amount),0);
  const pendingUtang=utang.filter(u=>u.status==='pending').reduce((a,u)=>a+Number(u.amount),0);
  const paidUtang=utang.filter(u=>u.status==='paid').reduce((a,u)=>a+Number(u.amount),0);
  const collectionRate=totalUtang>0?Math.round((paidUtang/totalUtang)*100):0;
  res.json({ totalItems:items.length,inStock:items.filter(i=>i.stock==='in').length,totalUsers:users.length,totalRecords:utang.length,totalUtang,pendingUtang,paidUtang,collectionRate,pendingCount:utang.filter(u=>u.status==='pending').length,paidCount:utang.filter(u=>u.status==='paid').length,monthlyTrend:Object.values(months),topDebtors,topItems,acBreakdown,paymentMethods,calData,recentUtang:[...utang].reverse().slice(0,5) });
});

// ── STATS ──
app.get('/api/stats', (req,res) => {
  const items=readDB('items.json'); const utang=readDB('utang.json');
  const lowStock=items.filter(i=>i.stockCount!==null&&i.stockCount!==undefined&&i.stockCount<=( i.lowStockAlert||5)&&i.stock==='in');
  const totalUtang=utang.reduce((a,u)=>a+Number(u.amount),0);
  const pendingUtang=utang.filter(u=>u.status==='pending').reduce((a,u)=>a+Number(u.amount),0);
  const paidUtang=utang.filter(u=>u.status==='paid').reduce((a,u)=>a+Number(u.amount),0);
  res.json({ totalItems:items.length,inStock:items.filter(i=>i.stock==='in').length,totalUtang,pendingUtang,paidUtang,totalRecords:utang.length,pendingCount:utang.filter(u=>u.status==='pending').length,paidCount:utang.filter(u=>u.status==='paid').length,lowStockCount:lowStock.length,lowStockItems:lowStock.slice(0,3),recentUtang:[...utang].reverse().slice(0,5) });
});

// ── NOTIFICATIONS ──
app.get('/api/notifications', (req,res) => res.json(checkOverdue()));
app.put('/api/notifications/read-all', (req,res) => { const n=readDB('notifications.json'); n.forEach(x=>x.read=true); writeDB('notifications.json',n); res.json({success:true}); });
app.delete('/api/notifications/:id', (req,res) => { writeDB('notifications.json',readDB('notifications.json').filter(n=>n.id!==parseInt(req.params.id))); res.json({success:true}); });

// ── LOGS ──
app.get('/api/logs', (req,res) => res.json([...readDB('logs.json')].reverse().slice(0,200)));
app.delete('/api/logs', (req,res) => { writeDB('logs.json',[]); res.json({success:true}); });

// ── EXPORT ──
app.get('/api/export/utang', (req,res) => {
  const utang=readDB('utang.json'); const s=getS();
  const {account,status}=req.query;
  let list=utang;
  if(account) list=list.filter(u=>u.account===account);
  if(status)  list=list.filter(u=>u.status===status);
  const total=list.reduce((a,u)=>a+Number(u.amount),0);
  const pending=list.filter(u=>u.status==='pending').reduce((a,u)=>a+Number(u.amount),0);
  const csv=[
    `"${s.shopName||'JamFamily SHOP'} — Utang Export (${new Date().toLocaleDateString('en-PH')})"`,
    `"Filter: ${account||'All'} / ${status||'All'}"`,
    '',
    '"#","Name","Items","Amount","Paid","Balance","Account","Due Date","Date","Status","Note","Payment Method"',
    ...list.map((u,i)=>[
      i+1,`"${u.name}"`,
      `"${u.items?u.items.map(r=>`${r.name} x${r.qty}`).join('; '):u.item}"`,
      Number(u.amount).toFixed(2),
      Number(u.paidAmount||0).toFixed(2),
      (Number(u.amount)-Number(u.paidAmount||0)).toFixed(2),
      `"${u.account||u.by}"`,`"${u.dueDate||''}"`,`"${u.date}"`,`"${u.status}"`,`"${u.note||''}"`,`"${u.paymentMethod||''}"`
    ].join(',')),
    '',`"Total","","",${total.toFixed(2)},"","","","","","","",""`,
    `"Pending","","",${pending.toFixed(2)},"","","","","","","",""`
  ].join('\n');
  res.setHeader('Content-Type','text/csv; charset=utf-8');
  res.setHeader('Content-Disposition',`attachment; filename="utang_${Date.now()}.csv"`);
  res.send('\uFEFF'+csv);
});

// ── CALENDAR DATA ──
app.get('/api/calendar', (req,res) => {
  const utang=readDB('utang.json');
  const {year,month}=req.query;
  const cal={};
  utang.forEach(u => {
    const d=new Date(u.dateISO||u.date);
    if(year&&d.getFullYear()!==parseInt(year)) return;
    if(month&&d.getMonth()+1!==parseInt(month)) return;
    const k=d.toISOString().split('T')[0];
    if(!cal[k]) cal[k]={date:k,count:0,amount:0,names:[]};
    cal[k].count++; cal[k].amount+=Number(u.amount);
    if(!cal[k].names.includes(u.name)) cal[k].names.push(u.name);
  });
  res.json(Object.values(cal));
});

// ── SERVE ──
app.get('*',(req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT, () => {
  console.log(`\n🌙 JamFamily SHOP v4.0`);
  console.log(`   http://localhost:${PORT}\n`);
});
