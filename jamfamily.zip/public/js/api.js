/**
 * JamFamily SHOP — API Layer
 * Handles all communication with the backend server.
 * Falls back to localStorage if server is not running.
 */

const API_BASE = window.location.origin;
let USE_LOCAL = false; // auto-detected on first call

// ── DETECT SERVER ────────────────────────────────────────────────
async function detectServer() {
  try {
    const res = await fetch(`${API_BASE}/api/settings`, { signal: AbortSignal.timeout(2000) });
    USE_LOCAL = !res.ok;
  } catch {
    USE_LOCAL = true;
    console.warn('[JamFamily] Server not found — running in offline/localStorage mode.');
  }
  updateDBStatus();
}

function updateDBStatus() {
  const files = document.querySelectorAll('.db-badge');
  files.forEach(el => {
    el.textContent = USE_LOCAL ? 'Offline (localStorage)' : 'Connected';
    el.className = 'db-badge ' + (USE_LOCAL ? 'err' : 'ok');
  });
  const apiStatus = document.getElementById('api-status');
  if (apiStatus) {
    apiStatus.innerHTML = USE_LOCAL
      ? `<div style="font-size:.75rem;color:var(--warning);background:rgba(232,160,32,.08);border:1px solid rgba(232,160,32,.2);border-radius:9px;padding:.55rem .8rem">⚠️ Running offline. Start <code>node server.js</code> for full database support.</div>`
      : `<div style="font-size:.75rem;color:var(--success);background:rgba(77,186,116,.08);border:1px solid rgba(77,186,116,.2);border-radius:9px;padding:.55rem .8rem">✅ Connected to backend server. JSON files are being used as database.</div>`;
  }
}

// ── LOCAL STORAGE FALLBACK ───────────────────────────────────────
const DEFAULT_LOCAL = {
  users: [
    { id: 1, username: 'admin', password: 'admin123', role: 'admin', createdAt: '2025-01-01' },
    { id: 2, username: 'user1', password: 'user123',  role: 'user',  createdAt: '2025-01-01' }
  ],
  items: [
    { id:1, name:'Max Energy Drink', emoji:'🥤', photo:'', price:35, stock:'in', category:'Drinks', sold:0 },
    { id:2, name:'Chippy BBQ',        emoji:'🍟', photo:'', price:10, stock:'in', category:'Snacks', sold:0 },
    { id:3, name:'C2 Green Tea',      emoji:'🍵', photo:'', price:20, stock:'in', category:'Drinks', sold:0 },
    { id:4, name:'Pancit Canton',     emoji:'🍜', photo:'', price:15, stock:'out',category:'Food',   sold:0 },
    { id:5, name:'Nova Cheddar',      emoji:'🧀', photo:'', price:12, stock:'in', category:'Snacks', sold:0 },
    { id:6, name:'Kopiko Candy',      emoji:'🍬', photo:'', price:3,  stock:'in', category:'Snacks', sold:0 },
    { id:7, name:'Skyflakes',         emoji:'🍘', photo:'', price:8,  stock:'in', category:'Snacks', sold:0 },
    { id:8, name:'Zesto Juice',       emoji:'🧃', photo:'', price:10, stock:'in', category:'Drinks', sold:0 },
  ],
  utang: [],
  settings: { shopName:'JamFamily SHOP', tagline:'Your trusted neighborhood shop', theme:'gold', nextItemId:9, nextUserId:3, nextUtangId:1 }
};

function localGet(key) {
  try { return JSON.parse(localStorage.getItem('jf_' + key)); } catch { return null; }
}
function localSet(key, val) {
  localStorage.setItem('jf_' + key, JSON.stringify(val));
}
function initLocal() {
  if (!localGet('items'))    localSet('items',    DEFAULT_LOCAL.items);
  if (!localGet('users'))    localSet('users',    DEFAULT_LOCAL.users);
  if (!localGet('utang'))    localSet('utang',    DEFAULT_LOCAL.utang);
  if (!localGet('settings')) localSet('settings', DEFAULT_LOCAL.settings);
}

// ── HTTP HELPERS ─────────────────────────────────────────────────
async function http(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API_BASE + path, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

// ── AUTH ─────────────────────────────────────────────────────────
const API = {
  async login(username, password) {
    if (USE_LOCAL) {
      initLocal();
      const users = localGet('users');
      const user = users.find(u => u.username === username && u.password === password);
      if (!user) throw new Error('Wrong username or password');
      const { password: _, ...safe } = user;
      return { success: true, user: safe };
    }
    return http('POST', '/api/login', { username, password });
  },

  // ── PHOTO UPLOAD ──
  async uploadPhoto(file) {
    if (USE_LOCAL) {
      // In offline mode: convert to base64 data URL and store inline
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve({ success: true, url: reader.result });
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
      });
    }
    const formData = new FormData();
    formData.append('photo', file);
    const res = await fetch(`${API_BASE}/api/upload`, { method: 'POST', body: formData });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Upload failed' }));
      throw new Error(err.error || 'Upload failed');
    }
    return res.json();
  },
  async getItems() {
    if (USE_LOCAL) { initLocal(); return localGet('items'); }
    return http('GET', '/api/items');
  },
  async addItem(data) {
    if (USE_LOCAL) {
      const items = localGet('items');
      const s = localGet('settings');
      const item = { id: s.nextItemId++, sold: 0, ...data };
      items.push(item); localSet('items', items); localSet('settings', s);
      return item;
    }
    return http('POST', '/api/items', data);
  },
  async updateItem(id, data) {
    if (USE_LOCAL) {
      const items = localGet('items');
      const idx = items.findIndex(i => i.id === id);
      if (idx === -1) throw new Error('Not found');
      items[idx] = { ...items[idx], ...data };
      localSet('items', items); return items[idx];
    }
    return http('PUT', `/api/items/${id}`, data);
  },
  async deleteItem(id) {
    if (USE_LOCAL) {
      localSet('items', localGet('items').filter(i => i.id !== id));
      return { success: true };
    }
    return http('DELETE', `/api/items/${id}`);
  },

  // ── UTANG ──
  async getUtang(params = {}) {
    if (USE_LOCAL) {
      initLocal();
      let list = [...localGet('utang')].reverse();
      if (params.account) list = list.filter(u => u.account === params.account || u.by === params.account);
      if (params.status)  list = list.filter(u => u.status === params.status);
      if (params.search)  list = list.filter(u => u.name.toLowerCase().includes(params.search.toLowerCase()) || (u.item||'').toLowerCase().includes(params.search.toLowerCase()));
      return list;
    }
    const qs = new URLSearchParams(params).toString();
    return http('GET', `/api/utang${qs ? '?' + qs : ''}`);
  },
  async addUtang(data) {
    if (USE_LOCAL) {
      const utang = localGet('utang');
      const s = localGet('settings');
      const record = { id: s.nextUtangId++, date: new Date().toLocaleDateString('en-PH'), dateISO: new Date().toISOString(), status: 'pending', ...data };
      utang.push(record); localSet('utang', utang); localSet('settings', s);
      return record;
    }
    return http('POST', '/api/utang', data);
  },
  async updateUtang(id, data) {
    if (USE_LOCAL) {
      const utang = localGet('utang');
      const idx = utang.findIndex(u => u.id === id);
      if (idx === -1) throw new Error('Not found');
      utang[idx] = { ...utang[idx], ...data };
      localSet('utang', utang); return utang[idx];
    }
    return http('PUT', `/api/utang/${id}`, data);
  },
  async deleteUtang(id) {
    if (USE_LOCAL) {
      localSet('utang', localGet('utang').filter(u => u.id !== id));
      return { success: true };
    }
    return http('DELETE', `/api/utang/${id}`);
  },
  async markAllPaid(name, note = '', changedBy = 'admin') {
    if (USE_LOCAL) {
      const utang = localGet('utang');
      utang.forEach(u => {
        if (u.name === name && u.status === 'pending') {
          if (!u.history) u.history = [];
          u.history.push({ from:'pending', to:'paid', note, by:changedBy, dateISO:new Date().toISOString(), date:new Date().toLocaleDateString('en-PH'), time:new Date().toLocaleTimeString('en-PH') });
          u.status = 'paid';
        }
      });
      localSet('utang', utang); return { success: true };
    }
    return http('PUT', `/api/utang/person/${encodeURIComponent(name)}/paid`, { paymentNote: note, changedBy });
  },

  // ── USERS ──
  async getUsers() {
    if (USE_LOCAL) {
      initLocal();
      return localGet('users').map(({ password: _, ...u }) => u);
    }
    return http('GET', '/api/users');
  },
  async addUser(data) {
    if (USE_LOCAL) {
      const users = localGet('users');
      const s = localGet('settings');
      if (users.find(u => u.username === data.username)) throw new Error('Username already exists');
      const user = { id: s.nextUserId++, createdAt: new Date().toLocaleDateString('en-PH'), ...data };
      users.push(user); localSet('users', users); localSet('settings', s);
      const { password: _, ...safe } = user; return safe;
    }
    return http('POST', '/api/users', data);
  },
  async deleteUser(id) {
    if (USE_LOCAL) {
      localSet('users', localGet('users').filter(u => u.id !== id));
      return { success: true };
    }
    return http('DELETE', `/api/users/${id}`);
  },
  async changePassword(id, oldPassword, newPassword) {
    if (USE_LOCAL) {
      const users = localGet('users');
      const idx = users.findIndex(u => u.id === id);
      if (idx === -1) throw new Error('User not found');
      if (users[idx].password !== oldPassword) throw new Error('Current password is wrong');
      if (!newPassword || newPassword.length < 4) throw new Error('New password must be at least 4 characters');
      users[idx].password = newPassword;
      localSet('users', users); return { success: true };
    }
    return http('PUT', `/api/users/${id}/password`, { oldPassword, newPassword });
  },

  // ── SETTINGS ──
  async getSettings() {
    if (USE_LOCAL) { initLocal(); const s = localGet('settings'); const { nextItemId: _a, nextUserId: _b, nextUtangId: _c, ...pub } = s; return pub; }
    return http('GET', '/api/settings');
  },
  async saveSettings(data) {
    if (USE_LOCAL) {
      const s = { ...localGet('settings'), ...data };
      localSet('settings', s); return { success: true };
    }
    return http('PUT', '/api/settings', data);
  },

  // ── STATS ──
  async getStats() {
    if (USE_LOCAL) {
      initLocal();
      const items  = localGet('items');
      const utang  = localGet('utang');
      const users  = localGet('users');
      const totalUtang   = utang.reduce((a, u) => a + Number(u.amount), 0);
      const pendingUtang = utang.filter(u => u.status === 'pending').reduce((a, u) => a + Number(u.amount), 0);
      const paidUtang    = utang.filter(u => u.status === 'paid').reduce((a, u) => a + Number(u.amount), 0);
      return {
        totalItems: items.length, inStock: items.filter(i => i.stock === 'in').length,
        outOfStock: items.filter(i => i.stock === 'out').length,
        totalUsers: users.length, totalUtang, pendingUtang, paidUtang,
        totalRecords: utang.length,
        pendingCount: utang.filter(u => u.status === 'pending').length,
        paidCount:    utang.filter(u => u.status === 'paid').length,
        recentUtang:  [...utang].reverse().slice(0, 5)
      };
    }
    return http('GET', '/api/stats');
  },

  // ── ANALYTICS ──
  async getAnalytics() {
    if (USE_LOCAL) {
      // Local fallback: build analytics from localStorage
      const items  = localGet('items') || [];
      const utang  = localGet('utang') || [];
      const users  = localGet('users') || [];
      const totalUtang   = utang.reduce((a,u)=>a+Number(u.amount),0);
      const pendingUtang = utang.filter(u=>u.status==='pending').reduce((a,u)=>a+Number(u.amount),0);
      const paidUtang    = utang.filter(u=>u.status==='paid').reduce((a,u)=>a+Number(u.amount),0);
      const collectionRate = totalUtang > 0 ? Math.round((paidUtang/totalUtang)*100) : 0;
      const months = {};
      for (let i=5;i>=0;i--) { const d=new Date(); d.setMonth(d.getMonth()-i); const k=d.toLocaleDateString('en-PH',{month:'short',year:'numeric'}); months[k]={month:k,total:0,paid:0,pending:0,count:0}; }
      utang.forEach(u=>{ const d=new Date(u.dateISO||u.date); const k=d.toLocaleDateString('en-PH',{month:'short',year:'numeric'}); if(months[k]){months[k].total+=Number(u.amount);months[k].count++;if(u.status==='paid')months[k].paid+=Number(u.amount);else months[k].pending+=Number(u.amount);} });
      const debtors={};
      utang.filter(u=>u.status==='pending').forEach(u=>{if(!debtors[u.name])debtors[u.name]=0;debtors[u.name]+=Number(u.amount);});
      const topDebtors=Object.entries(debtors).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([name,amount])=>({name,amount}));
      const itemFreq={};
      utang.forEach(u=>{if(u.items)u.items.forEach(it=>{if(!itemFreq[it.name])itemFreq[it.name]={name:it.name,emoji:it.emoji,count:0,revenue:0};itemFreq[it.name].count+=it.qty||1;itemFreq[it.name].revenue+=Number(it.sub||0);});});
      const topItems=Object.values(itemFreq).sort((a,b)=>b.count-a.count).slice(0,5);
      const acBreakdown=users.map(u=>{const myU=utang.filter(t=>t.account===u.username);const pending=myU.filter(t=>t.status==='pending').reduce((a,t)=>a+Number(t.amount),0);const paid=myU.filter(t=>t.status==='paid').reduce((a,t)=>a+Number(t.amount),0);return{username:u.username,role:u.role,records:myU.length,pending,paid};});
      const calData={};const c35=new Date(Date.now()-35*86400000);utang.forEach(u=>{const d=new Date(u.dateISO||u.date);if(d>=c35){const k=d.toISOString().split('T')[0];if(!calData[k])calData[k]={date:k,count:0,amount:0,names:[]};calData[k].count++;calData[k].amount+=Number(u.amount);if(!calData[k].names.includes(u.name))calData[k].names.push(u.name);}});
      return { totalItems:items.length, inStock:items.filter(i=>i.stock==='in').length, totalUsers:users.length, totalRecords:utang.length, totalUtang, pendingUtang, paidUtang, collectionRate, pendingCount:utang.filter(u=>u.status==='pending').length, paidCount:utang.filter(u=>u.status==='paid').length, monthlyTrend:Object.values(months), topDebtors, topItems, acBreakdown, paymentMethods:[], calData, recentUtang:[...utang].reverse().slice(0,5) };
    }
    return http('GET', '/api/analytics');
  },

  // ── PRESETS ──
  async getPresets() {
    if (USE_LOCAL) { initLocal(); return localGet('presets')||[]; }
    return http('GET', '/api/presets');
  },
  async addPreset(data) {
    if (USE_LOCAL) {
      const presets=localGet('presets')||[]; const s=localGet('settings');
      if(!s.nextPresetId) s.nextPresetId=1;
      const p={id:s.nextPresetId++,createdAt:new Date().toLocaleDateString('en-PH'),...data};
      presets.push(p); localSet('presets',presets); localSet('settings',s); return p;
    }
    return http('POST', '/api/presets', data);
  },
  async deletePreset(id) {
    if (USE_LOCAL) { localSet('presets',(localGet('presets')||[]).filter(p=>p.id!==id)); return {success:true}; }
    return http('DELETE', `/api/presets/${id}`);
  },

  // ── PAYMENTS ──
  async getPayments(utangId) {
    if (USE_LOCAL) { return (localGet('payments')||[]).filter(p=>p.utangId===utangId); }
    return http('GET', `/api/payments?utangId=${utangId}`);
  },

  // ── CALENDAR ──
  async getCalendar(year, month) {
    if (USE_LOCAL) {
      const utang=localGet('utang')||[]; const cal={};
      utang.forEach(u=>{const d=new Date(u.dateISO||u.date);if(year&&d.getFullYear()!==year)return;if(month&&d.getMonth()+1!==month)return;const k=d.toISOString().split('T')[0];if(!cal[k])cal[k]={date:k,count:0,amount:0,names:[]};cal[k].count++;cal[k].amount+=Number(u.amount);if(!cal[k].names.includes(u.name))cal[k].names.push(u.name);});
      return Object.values(cal);
    }
    return http('GET', `/api/calendar?year=${year}&month=${month}`);
  },

  // ── LOGO ──
  async uploadLogo(file) {
    if (USE_LOCAL) {
      return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>{const url=r.result;const s=localGet('settings');s.logoUrl=url;localSet('settings',s);res({success:true,url});};r.onerror=()=>rej(new Error('Failed'));r.readAsDataURL(file);});
    }
    const fd=new FormData(); fd.append('logo',file);
    const r=await fetch(`${API_BASE}/api/upload/logo`,{method:'POST',body:fd});
    if(!r.ok) throw new Error('Upload failed');
    return r.json();
  },

  // ── LOGS ──
  async getLogs() {
    if (USE_LOCAL) return [];
    return http('GET', '/api/logs');
  }
};

// ── INIT ─────────────────────────────────────────────────────────
detectServer();
