/**
 * JamFamily SHOP — Animated Night Sky Background
 */
(function () {
  const c = document.getElementById('bg-canvas');
  const ctx = c.getContext('2d');
  let stars = [], shooters = [];

  function resize() {
    c.width = innerWidth; c.height = innerHeight; stars = [];
    for (let i = 0; i < 300; i++) {
      stars.push({
        x: Math.random() * c.width, y: Math.random() * c.height,
        r: Math.random() * 1.5 + .15, a: Math.random(),
        s: Math.random() * .006 + .0015, d: Math.random() > .5 ? 1 : -1,
        w: Math.random() > .8
      });
    }
  }

  function getSkyColors() {
    const t = document.body.className;
    if (t.includes('galaxy'))  return ['#02010c','#050318','#070521','#090826'];
    if (t.includes('fire'))    return ['#0f0200','#160400','#1a0500','#1e0700'];
    if (t.includes('ocean'))   return ['#00080f','#000d18','#001020','#001328'];
    if (t.includes('forest'))  return ['#010801','#020f02','#031204','#041506'];
    return ['#01010c','#040416','#060820','#080c26'];
  }

  function getStarColors() {
    const t = document.body.className;
    if (t.includes('galaxy'))  return ['rgba(180,140,255,','rgba(240,220,255,'];
    if (t.includes('fire'))    return ['rgba(255,180,100,','rgba(255,220,180,'];
    if (t.includes('ocean'))   return ['rgba(100,200,255,','rgba(200,240,255,'];
    if (t.includes('forest'))  return ['rgba(100,255,140,','rgba(200,255,210,'];
    return ['rgba(195,215,255,','rgba(255,240,195,'];
  }

  function draw() {
    const cols = getSkyColors();
    const g = ctx.createLinearGradient(0, 0, 0, c.height);
    g.addColorStop(0, cols[0]); g.addColorStop(.45, cols[1]);
    g.addColorStop(.8, cols[2]); g.addColorStop(1, cols[3]);
    ctx.fillStyle = g; ctx.fillRect(0, 0, c.width, c.height);

    // Nebula
    [[c.width * .16, c.height * .2, 230, 'rgba(50,20,100,'],
     [c.width * .8, c.height * .58, 165, 'rgba(12,42,90,'],
     [c.width * .5, c.height * .1, 125, 'rgba(35,15,75,']
    ].forEach(([x, y, r, cl]) => {
      const ng = ctx.createRadialGradient(x, y, 0, x, y, r);
      ng.addColorStop(0, cl + '.065)'); ng.addColorStop(1, cl + '0)');
      ctx.fillStyle = ng; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    });

    const [nc, wc] = getStarColors();
    stars.forEach(s => {
      s.a += s.s * s.d;
      if (s.a > 1 || s.a < .05) s.d *= -1;
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = (s.w ? wc : nc) + s.a + ')'; ctx.fill();
    });

    if (Math.random() > .997) {
      shooters.push({
        x: Math.random() * c.width * .5, y: Math.random() * c.height * .35,
        vx: 4 + Math.random() * 6, vy: 2 + Math.random() * 3.5,
        l: 1, m: 55 + Math.random() * 45
      });
    }
    shooters = shooters.filter(s => s.l > 0);
    shooters.forEach(s => {
      const al = s.l / s.m, tl = 55 + s.vx * 5;
      const sg = ctx.createLinearGradient(s.x - tl, s.y - (tl * s.vy / s.vx), s.x, s.y);
      sg.addColorStop(0, 'rgba(255,248,215,0)');
      sg.addColorStop(1, `rgba(255,248,215,${al * .8})`);
      ctx.beginPath();
      ctx.moveTo(s.x - tl, s.y - (tl * s.vy / s.vx));
      ctx.lineTo(s.x, s.y);
      ctx.strokeStyle = sg; ctx.lineWidth = 1.3 + al; ctx.stroke();
      s.x += s.vx; s.y += s.vy; s.l--;
    });

    requestAnimationFrame(draw);
  }

  // Drifting clouds
  const cl = document.getElementById('cloud-layer');
  const ks = document.createElement('style');
  ks.textContent = '@keyframes cD{from{transform:translateX(-320px)}to{transform:translateX(calc(100vw + 320px))}}';
  document.head.appendChild(ks);
  for (let i = 0; i < 7; i++) {
    const d = document.createElement('div'); d.className = 'cloud';
    const w = 90 + Math.random() * 210, h = w * .44;
    d.style.cssText = `width:${w}px;height:${h}px;left:${Math.random() * 110 - 10}%;top:${Math.random() * 62}%;opacity:${.18 + Math.random() * .28};animation:cD ${26 + Math.random() * 36}s linear ${-Math.random() * 36}s infinite`;
    cl.appendChild(d);
  }

  window.addEventListener('resize', resize);
  resize(); draw();
})();
