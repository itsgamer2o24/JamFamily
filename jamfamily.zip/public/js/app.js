/**
 * JamFamily SHOP — Main Application
 */

// ── STATE ────────────────────────────────────────────────────────
let cu = null;        // current user
let editId = null;    // item being edited
let selRole = 'user'; // role for new account
let selAc = null;     // selected account for utang
let utangF = 'all';   // utang filter
let adminF = 'all';   // admin utang filter
let adminAcF = null;  // admin account filter
let rowC = 0;         // item row counter
let curView = 'records'; // records | person

const THEMES = { gold:'🌙 Gold Moon', galaxy:'🌌 Galaxy', fire:'🔥 Fire', ocean:'🌊 Ocean', forest:'🌿 Forest' };

// ── UTILS ────────────────────────────────────────────────────────
function showMsg(id, text, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `<div class="msg ${type}">${text}</div>`;
  setTimeout(() => { if (el) el.innerHTML = ''; }, 3500);
}
function toggleEye(inputId, btn) {
  const i = document.getElementById(inputId);
  i.type = i.type === 'password' ? 'text' : 'password';
  btn.textContent = i.type === 'password' ? '👁' : '🙈';
}
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebar-overlay').classList.toggle('open');
}

// ── TOAST SYSTEM ──────────────────────────────────────────────────
function toast(msg, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span class="toast-icon">${icons[type]||'ℹ️'}</span><span style="flex:1">${msg}</span><button class="toast-close" onclick="dismissToast(this.parentElement)">✕</button>`;
  container.appendChild(t);
  setTimeout(() => dismissToast(t), duration);
}
function dismissToast(el) {
  if (!el || !el.parentElement) return;
  el.classList.add('out');
  setTimeout(() => el.remove(), 300);
}

// ── RIPPLE EFFECT ─────────────────────────────────────────────────
function addRipple(e) {
  const btn = e.currentTarget;
  const r   = document.createElement('span');
  const rect = btn.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height);
  r.className = 'ripple';
  r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px`;
  btn.appendChild(r);
  setTimeout(() => r.remove(), 500);
}

// ── PAGE TRANSITION ───────────────────────────────────────────────
function runPageTransition(fn) {
  const overlay = document.getElementById('page-transition');
  if (!overlay) { fn(); return; }
  overlay.classList.add('active');
  setTimeout(() => { fn(); overlay.classList.remove('active'); }, 180);
}

// ── SCROLL NAV SHADOW ────────────────────────────────────────────
window.addEventListener('scroll', () => {
  const nav = document.getElementById('top-nav');
  if (nav) nav.classList.toggle('nav-scrolled', window.scrollY > 10);
}, { passive: true });

// ── THEME ────────────────────────────────────────────────────────
function setTheme(t) {
  document.body.className = 'theme-' + t;
  document.querySelectorAll('.theme-dot').forEach(d => d.classList.remove('active'));
  const el = document.getElementById('td-' + t);
  if (el) el.classList.add('active');
  const lbl = document.getElementById('theme-label');
  if (lbl) lbl.textContent = 'Current: ' + (THEMES[t] || t);
  API.saveSettings({ theme: t }).catch(() => {});
}
async function applyTheme() {
  try { const s = await API.getSettings(); setTheme(s.theme || 'gold'); } catch { setTheme('gold'); }
}

// ── SHOP INFO ────────────────────────────────────────────────────
function applyShopInfo(s) {
  const n = s.shopName || 'JamFamily SHOP';
  const t = s.tagline  || 'Your trusted neighborhood shop';
  const nb = document.getElementById('nav-brand-text');
  const parts = n.split(' ');
  if (nb) nb.innerHTML = `${parts[0]}<span>${parts.slice(1).join(' ') ? ' ' + parts.slice(1).join(' ') : ''}</span>`;
  const ht = document.getElementById('home-title');      if (ht)   ht.textContent  = n;
  const htag = document.getElementById('home-tagline'); if (htag) htag.textContent = t;
  const lb = document.getElementById('login-brand');    if (lb)   lb.textContent  = n;
  const sb = document.getElementById('sb-brand');       if (sb)   sb.textContent  = n;
  document.title = n;
  const sn = document.getElementById('sett-name');     if (sn) sn.value = n;
  const st = document.getElementById('sett-tagline');  if (st) st.value = t;
}
async function saveShopInfo() {
  const n = document.getElementById('sett-name').value.trim();
  const t = document.getElementById('sett-tagline').value.trim();
  if (!n) { showMsg('sett-msg', 'Enter a shop name.', 'error'); return; }
  await API.saveSettings({ shopName: n, tagline: t });
  applyShopInfo({ shopName: n, tagline: t });
  showMsg('sett-msg', '✓ Saved!', 'success');
}

// ── AUTH ─────────────────────────────────────────────────────────
async function doLogin() {
  const u    = document.getElementById('login-user').value.trim();
  const p    = document.getElementById('login-pass').value;
  const btn  = document.getElementById('login-btn');
  const txt  = document.getElementById('login-btn-text');
  btn.disabled = true; if (txt) txt.textContent = '⏳ Signing in...';
  try {
    const res = await API.login(u, p);
    cu = res.user;
    closeModal('login-modal');
    updateNav();
    toast(`Welcome back, ${cu.username}! 👋`, 'success');
    runPageTransition(() => goPage('home'));
  } catch (e) {
    showMsg('login-msg', e.message, 'error');
    // shake animation
    const box = document.querySelector('#login-modal .modal-box');
    if (box) { box.style.animation='none'; box.offsetHeight; box.style.animation='shake .4s ease'; }
  } finally {
    btn.disabled = false; if (txt) txt.textContent = 'Sign In';
  }
}

function doLogout() {
  cu = null; selAc = null;
  toast('Logged out. See you! 👋', 'info');
  updateNav();
  runPageTransition(() => goPage('shop'));
}

// ── NAV ──────────────────────────────────────────────────────────
function updateNav() {
  const ua  = document.getElementById('user-area');
  const ids = [
    'nb-utang','nb-admin','nb-analytics','nb-settings','nb-login-btn',
    'bnb-home','bnb-utang','bnb-admin','bnb-analytics','bnb-profile','bnb-login-btn',
    'sb-utang','sb-admin','sb-analytics','sb-profile','sb-log','sb-settings',
    'notif-bell'
  ];
  const els = {}; ids.forEach(id => { const e = document.getElementById(id); if (e) els[id] = e; });

  if (cu) {
    const isA = cu.role === 'admin';
    els['nb-utang'].disabled   = false;
    els['nb-login-btn'].style.display = 'none';
    els['nb-admin'].style.display     = isA ? 'inline-flex' : 'none';
    els['nb-analytics'].style.display = isA ? 'inline-flex' : 'none';
    if (els['nb-settings']) els['nb-settings'].style.display = 'inline-flex';
    els['bnb-home'].disabled   = false;
    els['bnb-utang'].disabled  = false;
    els['bnb-login-btn'].style.display  = 'none';
    els['bnb-admin'].style.display      = isA ? 'flex' : 'none';
    els['bnb-analytics'].style.display  = isA ? 'flex' : 'none';
    els['bnb-profile'].style.display    = 'flex';
    els['sb-utang'].disabled   = false;
    els['sb-admin'].style.display     = isA ? 'block' : 'none';
    els['sb-analytics'].style.display = isA ? 'block' : 'none';
    els['sb-profile'].style.display   = 'block';
    els['sb-log'].style.display       = isA ? 'block' : 'none';
    els['sb-settings'].style.display  = 'block';
    els['notif-bell'].style.display   = isA ? 'flex' : 'none';
    ua.innerHTML = `
      <div class="user-pill" onclick="goPage('profile')" style="cursor:pointer">
        <div class="u-av">${cu.username.slice(0,2).toUpperCase()}</div>
        ${cu.username}
        <span style="font-size:.58rem;color:var(--text-muted);margin-left:2px">(${cu.role})</span>
      </div>
      <button class="logout-btn" onclick="doLogout()">Logout</button>`;
    const sbu = document.getElementById('sb-user');
    if (sbu) sbu.innerHTML = `<div style="font-weight:700;color:var(--a2);cursor:pointer" onclick="goPage('profile');toggleSidebar()">${cu.username}</div><div style="font-size:.7rem;color:var(--text-muted)">${cu.role}</div>`;
    const sbl = document.getElementById('sb-logout');
    if (sbl) sbl.innerHTML = `<button class="btn btn-danger btn-sm" onclick="doLogout();toggleSidebar()" style="width:100%">Logout</button>`;
    if (isA) loadNotifications();
  } else {
    els['nb-utang'].disabled   = true;
    els['nb-login-btn'].style.display = 'inline-flex';
    els['nb-admin'].style.display     = 'none';
    els['nb-analytics'].style.display = 'none';
    if (els['nb-settings']) els['nb-settings'].style.display = 'none';
    els['bnb-home'].disabled   = true;
    els['bnb-utang'].disabled  = true;
    els['bnb-login-btn'].style.display  = 'flex';
    els['bnb-admin'].style.display      = 'none';
    els['bnb-analytics'].style.display  = 'none';
    els['bnb-profile'].style.display    = 'none';
    els['sb-utang'].disabled   = true;
    els['sb-admin'].style.display     = 'none';
    els['sb-analytics'].style.display = 'none';
    els['sb-profile'].style.display   = 'none';
    els['sb-log'].style.display       = 'none';
    els['sb-settings'].style.display  = 'none';
    els['notif-bell'].style.display   = 'none';
    ua.innerHTML = '';
    const sbu = document.getElementById('sb-user');
    if (sbu) sbu.innerHTML = `<div style="font-size:.75rem;color:var(--text-muted)">Not logged in</div>`;
    const sbl = document.getElementById('sb-logout');
    if (sbl) sbl.innerHTML = `<button class="btn btn-primary btn-sm" onclick="openModal('login-modal');toggleSidebar()" style="width:100%">🔑 Login</button>`;
  }
}

function goPage(pg) {
  const protectedPages = ['utang','admin','home','settings','analytics','profile','log'];
  if (!cu && protectedPages.includes(pg)) { openModal('login-modal'); return; }
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn, .bnav-btn').forEach(b => b.classList.remove('active'));
  ['page-','nb-','bnb-'].forEach(pre => {
    const e = document.getElementById(pre + pg); if (e) e.classList.add('active');
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (pg === 'home')      renderHome();
  if (pg === 'shop')      renderShop();
  if (pg === 'utang')     { initUtangPage(); renderUtangCards(); }
  if (pg === 'admin')     { renderAdminItems(); renderAccounts(); renderAdminUtang(); renderAdminByPerson(); }
  if (pg === 'analytics') renderAnalytics();
  if (pg === 'profile')   renderProfile();
  if (pg === 'log')       renderLogs();
  if (pg === 'settings')  initSettingsPage();
}

// ── HOME ─────────────────────────────────────────────────────────
async function renderHome() {
  const heroUser = document.getElementById('hero-user');
  if (heroUser) heroUser.textContent = cu ? cu.username : 'Guest';

  try {
    const [stats, items] = await Promise.all([API.getStats(), API.getItems()]);

    document.getElementById('home-stats').innerHTML = `
      <div class="stat-card">
        <div class="s-icon">📦</div>
        <div class="s-num">${stats.totalItems}</div>
        <div class="s-lbl">Total Items</div>
        <div class="s-trend" style="color:var(--success)">${stats.inStock} in stock</div>
      </div>
      <div class="stat-card">
        <div class="s-icon">💸</div>
        <div class="s-num" style="font-size:1.3rem">₱${stats.totalUtang.toFixed(0)}</div>
        <div class="s-lbl">Total Utang</div>
        <div class="s-trend" style="color:var(--warning)">₱${stats.pendingUtang.toFixed(0)} pending</div>
      </div>
      <div class="stat-card">
        <div class="s-icon">⏳</div>
        <div class="s-num">${stats.pendingCount}</div>
        <div class="s-lbl">Pending</div>
        <div class="s-trend" style="color:var(--text-muted)">${stats.totalRecords} total records</div>
      </div>
      <div class="stat-card">
        <div class="s-icon">✅</div>
        <div class="s-num" style="color:var(--success)">₱${stats.paidUtang.toFixed(0)}</div>
        <div class="s-lbl">Total Paid</div>
        <div class="s-trend" style="color:var(--success)">${stats.paidCount} records paid</div>
      </div>`;

    const rec = document.getElementById('home-recent');
    if (!stats.recentUtang.length) {
      rec.innerHTML = '<div style="color:var(--text-muted);font-size:.8rem;padding:.3rem 0">Wala pang utang records.</div>';
    } else {
      rec.innerHTML = stats.recentUtang.map(u => `
        <div style="display:flex;align-items:center;gap:.75rem;padding:.65rem 0;border-bottom:1px solid var(--card-border)">
          <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,rgba(255,255,255,.1),rgba(255,255,255,.03));border:2px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:.68rem;font-weight:700;color:var(--a2);flex-shrink:0">${u.name.slice(0,2).toUpperCase()}</div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:.82rem">${u.name}</div>
            <div style="font-size:.68rem;color:var(--text-muted)">${u.items ? u.items.map(r=>`${r.emoji}${r.name}×${r.qty}`).join(' · ') : u.item}</div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-weight:700;font-size:.85rem;color:var(--a2)">₱${Number(u.amount).toFixed(2)}</div>
            <span class="badge ${u.status==='paid'?'b-paid':'b-pending'}">${u.status==='paid'?'✅':'⏳'}</span>
          </div>
        </div>`).join('');
    }

    const prev = document.getElementById('home-items-preview');
    prev.innerHTML = items.slice(0, 4).map(i => `
      <div style="display:flex;align-items:center;gap:.65rem;padding:.55rem 0;border-bottom:1px solid var(--card-border)">
        <span style="font-size:1.4rem">${i.emoji || '📦'}</span>
        <div style="flex:1"><div style="font-weight:700;font-size:.82rem">${i.name}</div><div style="font-size:.68rem;color:var(--text-muted)">${i.category || ''}</div></div>
        <div style="text-align:right">
          <div style="font-weight:700;font-size:.82rem;color:var(--a2)">₱${Number(i.price).toFixed(2)}</div>
          <span class="s-stock ${i.stock==='in'?'s-in':'s-out'}">${i.stock==='in'?'✔':'✕'}</span>
        </div>
      </div>`).join('');

  } catch (e) {
    document.getElementById('home-stats').innerHTML = `<div style="color:var(--text-muted);font-size:.8rem">Failed to load stats.</div>`;
  }
}

// ── SHOP ─────────────────────────────────────────────────────────
let _allItems = [];
let _activeCat = '';

async function renderShop() {
  try {
    _allItems = await API.getItems();
    buildCatChips();
    filterShop();
  } catch {
    document.getElementById('shop-grid').innerHTML = '<div class="empty-state"><div class="empty-icon">🛒</div><p>Failed to load items.</p></div>';
  }
}

function buildCatChips() {
  const cats = [...new Set(_allItems.map(i => i.category).filter(Boolean))].sort();
  const el = document.getElementById('cat-chips');
  if (!el) return;
  el.innerHTML = `<button class="cat-chip active" onclick="setCat('',this)">All (${_allItems.length})</button>` +
    cats.map(c => {
      const cnt = _allItems.filter(i => i.category === c).length;
      return `<button class="cat-chip" onclick="setCat('${c.replace(/'/g,"\\'") }',this)">${c} (${cnt})</button>`;
    }).join('');
}

function setCat(cat, btn) {
  _activeCat = cat;
  document.querySelectorAll('.cat-chip').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  filterShop();
}

function filterShop() {
  const search = (document.getElementById('shop-search')?.value || '').toLowerCase();
  let list = _allItems.filter(i => {
    const matchSearch = !search || i.name.toLowerCase().includes(search) || (i.category||'').toLowerCase().includes(search);
    const matchCat    = !_activeCat || i.category === _activeCat;
    return matchSearch && matchCat;
  });
  const g = document.getElementById('shop-grid');
  if (!list.length) {
    g.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><p>No items found.</p></div>';
    return;
  }
  g.innerHTML = list.map((i, idx) => `
    <div class="shop-card ${i.stock==='out'?'out-of-stock':''} anim-scale-in" style="animation-delay:${idx * 0.05}s">
      ${i.stock==='out' ? '<span class="shop-badge s-out">Wala na</span>' : ''}
      <div class="shop-img">
        ${i.photo ? `<img src="${i.photo}" alt="${i.name}" onerror="this.style.display='none'">` : ''}
        <span class="s-emoji" style="${i.photo?'position:relative;z-index:1;text-shadow:0 2px 8px rgba(0,0,0,.7)':''}">${i.emoji||'📦'}</span>
      </div>
      <div class="shop-body">
        <div class="shop-cat">${i.category||''}</div>
        <div class="shop-name">${i.name}</div>
        <div class="shop-price">₱${Number(i.price).toFixed(2)}</div>
        <span class="s-stock ${i.stock==='in'?'s-in':'s-out'}">${i.stock==='in'?'✔ Available':'✕ Wala na'}</span>
      </div>
    </div>`).join('');
}

// ── UTANG PAGE ────────────────────────────────────────────────────
async function initUtangPage() {
  const isA = cu.role === 'admin';
  document.getElementById('utang-role-pill').textContent = isA ? 'Admin Mode' : 'User Mode';
  document.getElementById('utang-page-sub').textContent  = isA ? 'Mag-add ng bagong utang record' : 'Tingnan ang iyong mga utang records';
  document.getElementById('utang-admin-form').style.display  = isA ? 'block' : 'none';
  document.getElementById('utang-user-banner').style.display = isA ? 'none' : 'block';
  if (isA) {
    await renderAcPicker();
    const c = document.getElementById('utang-item-rows');
    c.innerHTML = ''; rowC = 0; addItemRow();
  } else {
    renderUserBanner();
  }
}
async function renderUserBanner() {
  try {
    const all = await API.getUtang({ account: cu.username });
    const total   = all.reduce((a, u) => a + Number(u.amount), 0);
    const pending = all.filter(u => u.status==='pending').reduce((a,u) => a + Number(u.amount), 0);
    const paidCnt = all.filter(u => u.status==='paid').length;
    document.getElementById('user-summary-banner').innerHTML = `
      <div class="ub-avatar">${cu.username.slice(0,2).toUpperCase()}</div>
      <div class="ub-info">
        <div class="ub-name">${cu.username}</div>
        <div style="margin-top:3px"><span class="badge b-user">👤 User Account</span></div>
        <div class="ub-stats">
          <div class="ub-stat"><div class="n">${all.length}</div><div class="l">Records</div></div>
          <div class="ub-stat"><div class="n" style="color:var(--warning)">₱${pending.toFixed(0)}</div><div class="l">Pending</div></div>
          <div class="ub-stat"><div class="n" style="color:var(--success)">${paidCnt}</div><div class="l">Paid</div></div>
          <div class="ub-stat"><div class="n" style="font-size:1rem">₱${total.toFixed(0)}</div><div class="l">Total</div></div>
        </div>
      </div>`;
  } catch {}
}

// ── ACCOUNT PICKER ────────────────────────────────────────────────
async function renderAcPicker() {
  try {
    const users = await API.getUsers();
    document.getElementById('utang-ac-picker').innerHTML = users.map(u => `
      <div class="ac-chip ${selAc===u.username?'sel':''}" onclick="selAccount('${u.username}')">
        <div class="av">${u.username.slice(0,2).toUpperCase()}</div>
        <div class="an">${u.username}</div>
        <div class="ar">${u.role==='admin'?'👑':'👤'} ${u.role}</div>
      </div>`).join('');
    const b = document.getElementById('sel-ac-badge');
    if (selAc) { b.style.display='block'; document.getElementById('sel-ac-name').textContent=selAc; }
    else b.style.display = 'none';
  } catch {}
}
function selAccount(u) { selAc = u; renderAcPicker(); }

// ── ITEM ROWS ─────────────────────────────────────────────────────
function buildOpts(sid) {
  return `<option value="">— Piliin ang item —</option>` +
    _allItems.map(i => `<option value="${i.id}"${sid==i.id?' selected':''}>${i.emoji||'📦'} ${i.name} — ₱${Number(i.price).toFixed(2)}</option>`).join('');
}
function addItemRow(iid, qty) {
  const id = ++rowC;
  const c  = document.getElementById('utang-item-rows');
  const d  = document.createElement('div'); d.className='urow'; d.id='ur-'+id;
  d.innerHTML = `
    <select id="us-${id}" onchange="recalc()">${buildOpts(iid||'')}</select>
    <input class="uqty" type="number" id="uq-${id}" min="1" value="${qty||1}" oninput="recalc()">
    <span class="urow-price" id="up-${id}">₱0.00</span>
    <button class="urow-del" onclick="delRow(${id})">✕</button>`;
  c.appendChild(d); recalc();
}
function delRow(id) { const e=document.getElementById('ur-'+id); if(e)e.remove(); recalc(); }
function recalc() {
  let tot = 0;
  document.querySelectorAll('.urow').forEach(row => {
    const rid = row.id.replace('ur-','');
    const sel = document.getElementById('us-'+rid);
    const qty = parseInt(document.getElementById('uq-'+rid)?.value) || 0;
    const pe  = document.getElementById('up-'+rid);
    if (!sel?.value) { if(pe) pe.textContent='₱0.00'; return; }
    const item = _allItems.find(i => i.id == sel.value);
    const sub  = item ? item.price * qty : 0;
    if (pe) pe.textContent = '₱' + sub.toFixed(2);
    tot += sub;
  });
  document.getElementById('utang-total-display').textContent = '₱' + tot.toFixed(2);
}
function getRows() {
  const rows = [];
  document.querySelectorAll('.urow').forEach(row => {
    const rid  = row.id.replace('ur-','');
    const sel  = document.getElementById('us-'+rid);
    const qty  = parseInt(document.getElementById('uq-'+rid)?.value) || 0;
    if (!sel?.value || qty < 1) return;
    const item = _allItems.find(i => i.id == sel.value);
    if (item) rows.push({ id:item.id, name:item.name, emoji:item.emoji, price:item.price, qty, sub:item.price*qty });
  });
  return rows;
}

// ── ADD UTANG ─────────────────────────────────────────────────────
async function addUtang() {
  if (cu.role !== 'admin') { showMsg('utang-msg','Only admin can add utang.','error'); return; }
  const name = document.getElementById('utang-name').value.trim();
  const note = document.getElementById('utang-note').value.trim();
  if (!selAc)  { showMsg('utang-msg','⚠️ Piliin muna ang account!','error'); return; }
  if (!name)   { showMsg('utang-msg','Lagyan ng pangalan.','error'); return; }
  const rows = getRows();
  if (!rows.length) { showMsg('utang-msg','Pumili ng kahit isang item.','error'); return; }
  const total = rows.reduce((s,r) => s + r.sub, 0);
  try {
    await API.addUtang({
      name, item: rows.map(r=>`${r.emoji}${r.name} x${r.qty}`).join(', '),
      items: rows, amount: total, note, by: cu.username, account: selAc
    });
    document.getElementById('utang-name').value = '';
    document.getElementById('utang-note').value = '';
    document.getElementById('utang-item-rows').innerHTML = '';
    rowC = 0; addItemRow(); recalc();
    showMsg('utang-msg', `✓ Utang ni "${name}" (₱${total.toFixed(2)}) saved sa account ni ${selAc}!`, 'success');
    toast(`Utang ni "${name}" — ₱${total.toFixed(2)} saved! 📋`, 'success');
    renderUtangCards();
  } catch (e) {
    showMsg('utang-msg', e.message, 'error');
  }
}

// ── VIEW SWITCH ───────────────────────────────────────────────────
function switchView(v, btn) {
  curView = v;
  document.querySelectorAll('.vt-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('view-records').style.display = v==='records' ? 'block' : 'none';
  document.getElementById('view-person').style.display  = v==='person'  ? 'block' : 'none';
  if (v === 'records') renderUtangCards();
  else renderPersonView();
}
function filterUtang(f, btn) {
  utangF = f;
  document.querySelectorAll('#page-utang .filter-bar .f-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  if (curView === 'records') renderUtangCards(); else renderPersonView();
}

async function renderUtangCards() {
  const container = document.getElementById('utang-cards');
  const empty     = document.getElementById('utang-empty');
  const search    = document.getElementById('utang-search')?.value.trim() || '';
  const params    = cu.role === 'admin' ? {} : { account: cu.username };
  if (utangF !== 'all') params.status = utangF;
  if (search) params.search = search;
  try {
    const list = await API.getUtang(params);
    if (!list.length) { container.innerHTML = ''; empty.style.display='block'; return; }
    empty.style.display = 'none';
    container.innerHTML = list.map(u => utangCardHTML(u, cu.role==='admin')).join('');
  } catch {
    container.innerHTML = '<div class="empty-state"><div class="empty-icon">⚠️</div><p>Failed to load records.</p></div>';
  }
}

async function renderPersonView() {
  const container = document.getElementById('person-cards');
  const empty     = document.getElementById('person-empty');
  const params    = cu.role === 'admin' ? {} : { account: cu.username };
  if (utangF !== 'all') params.status = utangF;
  try {
    const list = await API.getUtang(params);
    const grouped = {};
    list.forEach(u => { if (!grouped[u.name]) grouped[u.name]=[]; grouped[u.name].push(u); });
    const names = Object.keys(grouped);
    if (!names.length) { container.innerHTML=''; empty.style.display='block'; return; }
    empty.style.display = 'none';
    container.innerHTML = names.map(name => personCardHTML(name, grouped[name], cu.role==='admin')).join('');
  } catch {}
}

function utangCardHTML(u, canAct) {
  const initials = u.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const isOverdue = u.status === 'pending' && u.dateISO && (Date.now() - new Date(u.dateISO)) > 7*86400000;
  const lastH = u.history?.length ? u.history[u.history.length-1] : null;
  return `<div class="utang-card ${u.status==='paid'?'is-paid':''} ${isOverdue?'is-overdue':''}" id="uc-${u.id}">
    <div class="uc-top">
      <div class="uc-av">${initials}</div>
      <div class="uc-info">
        <div class="uc-name">${u.name} ${isOverdue?'<span class="overdue-badge">⚠️ Overdue</span>':''}</div>
        <div class="uc-note">${u.note ? `📝 ${u.note}` : '&nbsp;'}</div>
      </div>
      <div class="uc-amount">₱${Number(u.amount).toFixed(2)}</div>
    </div>
    <div class="uc-items">
      ${(u.items||[{name:u.item,emoji:'📦',qty:''}]).map(r=>`<span class="uc-item-tag">${r.emoji||'📦'} ${r.name}${r.qty?`<span class="qty">×${r.qty}</span>`:''}</span>`).join('')}
    </div>
    ${lastH ? `<div class="uc-history">💳 ${lastH.to==='paid'?'Paid':'Updated'} on ${lastH.date} by ${lastH.by}${lastH.note?' · '+lastH.note:''}</div>` : ''}
    <div class="uc-footer">
      <div class="uc-meta">
        <span class="badge ${u.status==='paid'?'b-paid':'b-pending'}">${u.status==='paid'?'✅ Paid':'⏳ Pending'}</span>
        <span class="badge b-user">👤 ${u.account||u.by}</span>
        <span style="font-size:.63rem;color:var(--text-muted)">📅 ${u.date}</span>
      </div>
      <div class="uc-actions">
        ${canAct ? `
          <button class="btn btn-sm ${u.status==='paid'?'btn-warn':'btn-success'}" onclick="openPaymentModal(${u.id},'${u.status}')">${u.status==='paid'?'↩ Undo':'✓ Paid'}</button>
          <button class="btn btn-sm btn-secondary" onclick="printReceipt(${u.id},this.closest('.utang-card').dataset.u)">🧾</button>
          <button class="btn btn-sm btn-danger" onclick="delUtang(${u.id})">🗑</button>
        ` : `<button class="btn btn-sm btn-secondary" onclick="printReceipt(${u.id},this.closest('.utang-card').dataset.u)">🧾 Receipt</button>`}
      </div>
    </div>
  </div>`;
}

// ── PAYMENT NOTE MODAL ────────────────────────────────────────────
let _pendingMarkPaidId = null, _pendingMarkPaidStatus = null;
function openPaymentModal(id, currentStatus) {
  _pendingMarkPaidId = id; _pendingMarkPaidStatus = currentStatus;
  if (currentStatus === 'paid') { confirmMarkPaid(); return; }
  const el = document.getElementById('payment-note'); if (el) el.value = '';
  openModal('payment-modal');
}
async function confirmMarkPaid() {
  const id = _pendingMarkPaidId, cur = _pendingMarkPaidStatus;
  const note = document.getElementById('payment-note')?.value.trim() || '';
  const newStatus = cur === 'paid' ? 'pending' : 'paid';
  closeModal('payment-modal');
  try {
    await API.updateUtang(id, { status: newStatus, paymentNote: note, changedBy: cu.username });
    toast(newStatus === 'paid' ? '✅ Marked as paid!' : '↩ Marked as pending', newStatus === 'paid' ? 'success' : 'info');
    refreshCurrentView();
    if (cu.role !== 'admin') renderUserBanner();
  } catch (e) { toast(e.message, 'error'); }
}

function togglePerson(eid) {
  const el = document.getElementById('pcr-' + eid);
  if (el) el.classList.toggle('open');
}

// ── MARK PAID / DELETE ────────────────────────────────────────────
async function delUtang(id) {
  if (!confirm('Delete this record?')) return;
  try { await API.deleteUtang(id); toast('Record deleted 🗑', 'info'); refreshCurrentView(); }
  catch (e) { toast(e.message, 'error'); }
}
async function markAllPaid(name, note, by) {
  if (!note) note = prompt('Payment note (optional):') || '';
  try { await API.markAllPaid(name, note || '', by || cu.username); toast(`All records ni "${name}" marked paid! ✅`, 'success'); refreshCurrentView(); }
  catch (e) { toast(e.message, 'error'); }
}
function refreshCurrentView() {
  const adminAllActive    = document.getElementById('asec-allutang')?.classList.contains('active');
  const adminPersonActive = document.getElementById('asec-byperson')?.classList.contains('active');
  if (adminAllActive) renderAdminUtang();
  else if (adminPersonActive) renderAdminByPerson();
  else if (curView === 'person') renderPersonView();
  else renderUtangCards();
}

// ── RECEIPT ───────────────────────────────────────────────────────
async function printReceipt(id, u) {
  const sett = await API.getSettings().catch(() => ({}));
  const shopName = sett.shopName || 'JamFamily SHOP';
  const tagline  = sett.tagline  || 'Your trusted neighborhood shop';
  const items = u.items || [{ name:u.item, emoji:'📦', qty:1, price:u.amount, sub:u.amount }];
  const area  = document.getElementById('receipt-print-area');
  area.style.display = 'block';
  area.innerHTML = `
    <div style="max-width:340px;margin:0 auto;font-family:'Quicksand',sans-serif;color:#111;padding:1.5rem">
      <div style="text-align:center;border-bottom:2px dashed #333;padding-bottom:1rem;margin-bottom:1rem">
        <div style="font-size:1.4rem;font-weight:900;letter-spacing:1px">${shopName}</div>
        <div style="font-size:.72rem;color:#555">${tagline}</div>
      </div>
      <div style="margin-bottom:.8rem">
        <div style="font-size:.68rem;color:#888;text-transform:uppercase;letter-spacing:1px">Customer</div>
        <div style="font-size:1.05rem;font-weight:700">${u.name}</div>
        ${u.note ? `<div style="font-size:.76rem;color:#555">📝 ${u.note}</div>` : ''}
      </div>
      <div style="margin-bottom:.8rem">
        <div style="font-size:.68rem;color:#888;text-transform:uppercase;letter-spacing:1px;margin-bottom:.3rem">Items</div>
        ${items.map(r=>`<div style="display:flex;justify-content:space-between;font-size:.84rem;padding:4px 0;border-bottom:1px solid #eee">
          <span>${r.emoji||''} ${r.name} × ${r.qty}</span>
          <span style="font-weight:700">₱${Number(r.sub||r.price).toFixed(2)}</span>
        </div>`).join('')}
      </div>
      <div style="display:flex;justify-content:space-between;font-size:1.1rem;font-weight:900;padding:.6rem 0;border-top:2px solid #333">
        <span>TOTAL</span><span>₱${Number(u.amount).toFixed(2)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:.76rem;color:#666;margin-top:.35rem">
        <span>📅 ${u.date}</span><span>Account: ${u.account||u.by}</span>
      </div>
      <div style="text-align:center;margin-top:.9rem;font-size:.7rem;color:#888;border-top:1px dashed #ccc;padding-top:.6rem">
        Status: ${u.status==='paid'?'✅ PAID':'⏳ PENDING'}<br>Salamat sa inyong tiwala! 🙏
      </div>
    </div>`;
  setTimeout(() => { window.print(); area.style.display='none'; }, 100);
}

async function printPersonReceipt(name, records) {
  const sett    = await API.getSettings().catch(() => ({}));
  const shopName = sett.shopName || 'JamFamily SHOP';
  const total   = records.reduce((s,r) => s+Number(r.amount), 0);
  const pending = records.filter(r=>r.status==='pending').reduce((s,r) => s+Number(r.amount), 0);
  const area    = document.getElementById('receipt-print-area');
  area.style.display = 'block';
  area.innerHTML = `
    <div style="max-width:360px;margin:0 auto;font-family:'Quicksand',sans-serif;color:#111;padding:1.5rem">
      <div style="text-align:center;border-bottom:2px dashed #333;padding-bottom:1rem;margin-bottom:1rem">
        <div style="font-size:1.4rem;font-weight:900">${shopName}</div>
        <div style="font-size:.72rem;color:#555">Summary Receipt</div>
      </div>
      <div style="font-size:1.05rem;font-weight:700;margin-bottom:.8rem">📋 ${name}</div>
      ${records.map(u=>`<div style="margin-bottom:.55rem;padding:.5rem;border:1px solid #ddd;border-radius:6px">
        <div style="font-size:.78rem;font-weight:700">${u.items?u.items.map(r=>`${r.emoji}${r.name}×${r.qty}`).join(', '):u.item}</div>
        <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-top:2px">
          <span style="color:#666">${u.date}</span>
          <span style="font-weight:700;color:${u.status==='paid'?'green':'#e84c0a'}">₱${Number(u.amount).toFixed(2)} ${u.status==='paid'?'✅':'⏳'}</span>
        </div>
      </div>`).join('')}
      <div style="border-top:2px solid #333;padding-top:.6rem;margin-top:.4rem">
        <div style="display:flex;justify-content:space-between;font-size:.9rem;font-weight:700"><span>Total</span><span>₱${total.toFixed(2)}</span></div>
        <div style="display:flex;justify-content:space-between;font-size:.82rem;color:#e84c0a;margin-top:2px"><span>Pending</span><span>₱${pending.toFixed(2)}</span></div>
      </div>
      <div style="text-align:center;margin-top:.8rem;font-size:.7rem;color:#888">Salamat sa inyong tiwala! 🙏</div>
    </div>`;
  setTimeout(() => { window.print(); area.style.display='none'; }, 100);
}

// ── ADMIN ITEMS ───────────────────────────────────────────────────
async function renderAdminItems() {
  const el = document.getElementById('admin-items-list');
  try {
    const items = await API.getItems();
    if (!items.length) { el.innerHTML = '<div class="empty-state"><div class="empty-icon">📦</div><p>No items.</p></div>'; return; }
    el.innerHTML = items.map(i => `
      <div class="item-row">
        <div class="item-thumb">
          ${i.photo
            ? `<img src="${i.photo}" alt="${i.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
            : ''}
          <span class="item-emoji" style="${i.photo?'display:none':'display:flex'}">${i.emoji||'📦'}</span>
        </div>
        <div class="item-details">
          <div class="item-name">${i.name}</div>
          <div class="item-meta">₱${Number(i.price).toFixed(2)} · <span class="item-cat-badge">${i.category||'—'}</span> · <span style="color:${i.stock==='in'?'var(--success)':'var(--danger)'}">${i.stock==='in'?'May Stock':'Wala na'}</span></div>
        </div>
        <div class="item-actions">
          <button class="btn btn-sm ${i.stock==='in'?'btn-danger':'btn-success'}" onclick="toggleStock(${i.id},'${i.stock}')">${i.stock==='in'?'Set Wala':'Set Stock'}</button>
          <button class="btn btn-sm btn-secondary" onclick="openItemModal(${i.id})">✏️ Edit</button>
          <button class="btn btn-sm btn-danger" onclick="delItem(${i.id})">🗑</button>
        </div>
      </div>`).join('');
  } catch { el.innerHTML = '<div class="empty-state"><p>Failed to load items.</p></div>'; }
}
async function toggleStock(id, current) {
  await API.updateItem(id, { stock: current==='in' ? 'out' : 'in' });
  renderAdminItems(); _allItems = await API.getItems();
}
async function delItem(id) {
  if (!confirm('Delete this item?')) return;
  await API.deleteItem(id); renderAdminItems(); _allItems = await API.getItems();
}

// ── ITEM MODAL PHOTO UPLOAD ───────────────────────────────────────
let _pendingPhotoFile = null; // file selected but not yet uploaded

function setEmoji(e) { document.getElementById('im-emoji').value = e; }

function handlePhotoSelect(event) {
  const file = event.target.files[0];
  if (!file) return;
  // validate
  const allowed = ['image/jpeg','image/png','image/gif','image/webp'];
  if (!allowed.includes(file.type)) {
    setPhotoStatus('❌ Only JPG, PNG, GIF, WEBP allowed.', 'error'); return;
  }
  if (file.size > 5 * 1024 * 1024) {
    setPhotoStatus('❌ File too large. Max 5MB.', 'error'); return;
  }
  _pendingPhotoFile = file;
  // show preview
  const reader = new FileReader();
  reader.onload = e => {
    showPhotoPreview(e.target.result);
    document.getElementById('photo-filename').textContent = file.name;
    setPhotoStatus('📎 Photo selected — will upload on Save', 'ok');
  };
  reader.readAsDataURL(file);
}

function showPhotoPreview(src) {
  const img = document.getElementById('photo-preview-img');
  const ph  = document.getElementById('photo-placeholder');
  const area = document.getElementById('photo-upload-area');
  img.src = src;
  img.style.display = 'block';
  ph.style.display  = 'none';
  area.classList.add('has-photo');
  document.getElementById('photo-remove-btn').style.display = 'inline-flex';
}

function removePhoto() {
  _pendingPhotoFile = null;
  document.getElementById('im-photo').value = '';
  document.getElementById('photo-preview-img').src = '';
  document.getElementById('photo-preview-img').style.display = 'none';
  document.getElementById('photo-placeholder').style.display = 'block';
  document.getElementById('photo-upload-area').classList.remove('has-photo');
  document.getElementById('photo-remove-btn').style.display = 'none';
  document.getElementById('photo-filename').textContent = '';
  document.getElementById('im-photo-file').value = '';
  setPhotoStatus('', '');
}

function setPhotoStatus(msg, type) {
  const el = document.getElementById('photo-upload-status');
  if (!msg) { el.innerHTML = ''; return; }
  const color = type==='error' ? 'var(--danger)' : type==='ok' ? 'var(--success)' : 'var(--text-muted)';
  el.innerHTML = `<span style="color:${color}">${msg}</span>`;
}

function setUploadProgress(pct) {
  let bar = document.getElementById('upload-progress-bar');
  if (!bar) {
    const area = document.getElementById('photo-upload-area');
    const wrap = document.createElement('div');
    wrap.className = 'upload-progress';
    wrap.innerHTML = '<div class="upload-progress-bar" id="upload-progress-bar"></div>';
    area.appendChild(wrap);
    bar = document.getElementById('upload-progress-bar');
  }
  bar.style.width = pct + '%';
  if (pct >= 100) setTimeout(() => { if (bar) bar.parentElement?.remove(); }, 600);
}

function openItemModal(id) {
  editId = id;
  _pendingPhotoFile = null;
  document.getElementById('item-modal-msg').innerHTML = '';
  removePhoto(); // reset photo UI

  if (id) {
    const i = _allItems.find(x => x.id === id);
    if (!i) { API.getItems().then(items => { _allItems=items; openItemModal(id); }); return; }
    document.getElementById('item-modal-title').textContent = 'Edit Item';
    document.getElementById('im-name').value  = i.name;
    document.getElementById('im-emoji').value = i.emoji || '';
    document.getElementById('im-photo').value = i.photo || '';
    document.getElementById('im-price').value = i.price;
    document.getElementById('im-stock').value = i.stock;
    document.getElementById('im-cat').value   = i.category || 'Snacks';
    if (i.photo) {
      showPhotoPreview(i.photo);
      document.getElementById('photo-filename').textContent = 'Current photo';
      setPhotoStatus('✅ Has photo — upload new to replace', 'ok');
    }
  } else {
    document.getElementById('item-modal-title').textContent = 'Add New Item';
    ['im-name','im-emoji','im-price'].forEach(x => document.getElementById(x).value = '');
    document.getElementById('im-stock').value = 'in';
    document.getElementById('im-cat').value   = 'Snacks';
  }
  openModal('item-modal');
}

function closeItemModal() { closeModal('item-modal'); editId = null; _pendingPhotoFile = null; }

async function saveItem() {
  const name  = document.getElementById('im-name').value.trim();
  const emoji = document.getElementById('im-emoji').value.trim();
  const price = document.getElementById('im-price').value;
  const stock = document.getElementById('im-stock').value;
  const category = document.getElementById('im-cat').value;
  if (!name || !price) { showMsg('item-modal-msg','Name and price required.','error'); return; }

  const btn = document.getElementById('save-item-btn');
  btn.disabled = true; btn.textContent = '⏳ Saving...';

  try {
    let photo = document.getElementById('im-photo').value || '';

    // Upload photo if a new file was selected
    if (_pendingPhotoFile) {
      setPhotoStatus('⬆️ Uploading photo...', '');
      setUploadProgress(30);
      const result = await API.uploadPhoto(_pendingPhotoFile);
      photo = result.url;
      setUploadProgress(100);
      setPhotoStatus('✅ Photo uploaded!', 'ok');
    }

    if (editId) await API.updateItem(editId, { name, emoji, photo, price:parseFloat(price), stock, category });
    else        await API.addItem({ name, emoji, photo, price:parseFloat(price), stock, category });

    _allItems = await API.getItems();
    closeItemModal();
    renderAdminItems();
    buildCatChips();
    toast(editId ? 'Item updated! ✏️' : 'Item added to shop! 🛍', 'success');
  } catch (e) {
    showMsg('item-modal-msg', e.message, 'error');
    setPhotoStatus('❌ ' + e.message, 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Save Item';
  }
}

// ── ADMIN ACCOUNTS ────────────────────────────────────────────────
function selectRole(role) {
  selRole = role;
  const uc = document.getElementById('role-user-card');
  const ac = document.getElementById('role-admin-card');
  uc.className = 'role-card' + (role==='user' ? ' role-active' : '');
  ac.className = 'role-card' + (role==='admin' ? ' role-active' : '');
  if (role==='admin') ac.style.cssText='background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.4)';
  else { ac.style.cssText=''; uc.style.cssText='background:rgba(77,186,116,.09);border-color:rgba(77,186,116,.4)'; }
}
async function createAccount() {
  const u = document.getElementById('new-username').value.trim();
  const p = document.getElementById('new-password').value;
  if (!u||!p)   { showMsg('account-msg','Username at password required.','error'); return; }
  if (u.length<3) { showMsg('account-msg','Username min 3 chars.','error'); return; }
  if (p.length<4) { showMsg('account-msg','Password min 4 chars.','error'); return; }
  try {
    await API.addUser({ username:u, password:p, role:selRole });
    document.getElementById('new-username').value = '';
    document.getElementById('new-password').value = '';
    showMsg('account-msg', `✓ Account "${u}" (${selRole}) created!`, 'success');
    renderAccounts();
  } catch (e) { showMsg('account-msg', e.message, 'error'); }
}
async function deleteAccount(id, uname) {
  if (uname === cu.username) { alert('Hindi mo ma-delete ang sarili mong account!'); return; }
  if (!confirm(`Delete account "${uname}"?`)) return;
  await API.deleteUser(id); renderAccounts();
}
async function renderAccounts() {
  const el = document.getElementById('accounts-grid');
  try {
    const [users, utangAll] = await Promise.all([API.getUsers(), API.getUtang()]);
    el.innerHTML = users.map(u => {
      const cnt     = utangAll.filter(t => t.account===u.username).length;
      const pending = utangAll.filter(t => t.account===u.username && t.status==='pending').reduce((a,t) => a+Number(t.amount), 0);
      const paid    = utangAll.filter(t => t.account===u.username && t.status==='paid').reduce((a,t) => a+Number(t.amount), 0);
      return `<div class="acc-card">
        <div class="acc-top">
          <div class="acc-av">${u.username.slice(0,2).toUpperCase()}</div>
          <div>
            <div class="acc-name">${u.username}${u.username===cu.username?' <span style="font-size:.6rem;color:var(--a2)">(you)</span>':''}</div>
            <div class="acc-sub"><span class="badge ${u.role==='admin'?'b-admin':'b-user'}">${u.role==='admin'?'👑 Admin':'👤 User'}</span></div>
          </div>
        </div>
        <div class="acc-stats">
          <div class="acc-stat"><div class="n">${cnt}</div><div class="l">Records</div></div>
          <div class="acc-stat"><div class="n" style="color:${pending>0?'var(--warning)':'var(--text-muted)'}">₱${pending.toFixed(0)}</div><div class="l">Pending</div></div>
          <div class="acc-stat"><div class="n" style="color:var(--success)">₱${paid.toFixed(0)}</div><div class="l">Paid</div></div>
          <div class="acc-stat"><div class="n" style="font-size:.82rem">₱${(pending+paid).toFixed(0)}</div><div class="l">Total</div></div>
        </div>
        <div class="acc-actions">
          <button class="btn btn-sm btn-secondary" style="flex:1" onclick="viewAcUtang('${u.username}')">👁 View Utang</button>
          <button class="btn btn-sm btn-danger" onclick="deleteAccount(${u.id},'${u.username}')">🗑</button>
        </div>
      </div>`;
    }).join('');
  } catch { el.innerHTML = '<p style="color:var(--text-muted);font-size:.8rem">Failed to load accounts.</p>'; }
}
function viewAcUtang(username) {
  adminAcF = username;
  document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
  document.querySelector('.admin-tab:nth-child(3)').classList.add('active');
  document.getElementById('asec-allutang').classList.add('active');
  renderAdminUtang();
}

// ── ADMIN UTANG ───────────────────────────────────────────────────
function adminFilterUtang(f, btn) {
  adminF = f; adminAcF = null;
  document.getElementById('ac-filter-tag').innerHTML = '';
  document.querySelectorAll('#asec-allutang .f-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active'); renderAdminUtang();
}
async function renderAdminUtang() {
  const container = document.getElementById('admin-utang-cards');
  const empty     = document.getElementById('admin-utang-empty');
  const params    = {};
  if (adminAcF && adminAcF !== 'all') params.account = adminAcF;
  if (adminF   !== 'all')             params.status  = adminF;
  const tag = document.getElementById('ac-filter-tag');
  tag.innerHTML = adminAcF
    ? `<span style="display:inline-flex;align-items:center;gap:5px;font-size:.7rem;background:rgba(255,255,255,.07);border:1px solid var(--card-border);border-radius:8px;padding:4px 10px;color:var(--a2)">
        Account: <strong>${adminAcF}</strong>
        <button onclick="clearAcF()" style="background:none;border:none;color:var(--danger);cursor:pointer;font-size:.8rem;padding:0;margin-left:2px">✕</button>
       </span>` : '';
  try {
    const list = await API.getUtang(params);
    if (!list.length) { container.innerHTML=''; empty.style.display='block'; return; }
    empty.style.display = 'none';
    container.innerHTML = list.map(u => utangCardHTML(u, true)).join('');
  } catch { container.innerHTML='<div class="empty-state"><p>Failed to load.</p></div>'; }
}
function clearAcF() { adminAcF=null; document.getElementById('ac-filter-tag').innerHTML=''; renderAdminUtang(); }

async function renderAdminByPerson() {
  const container = document.getElementById('admin-person-cards');
  const empty     = document.getElementById('admin-person-empty');
  try {
    const list = await API.getUtang();
    const grouped = {};
    list.forEach(u => { if (!grouped[u.name]) grouped[u.name]=[]; grouped[u.name].push(u); });
    const names = Object.keys(grouped);
    if (!names.length) { container.innerHTML=''; empty.style.display='block'; return; }
    empty.style.display='none';
    container.innerHTML = names.map(name => personCardHTML(name, grouped[name], true)).join('');
  } catch {}
}

// ── ADMIN TABS ────────────────────────────────────────────────────
function adminTab(tab, btn) {
  document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById('asec-' + tab).classList.add('active');
  adminAcF = null;
  if (tab==='allutang')  renderAdminUtang();
  if (tab==='accounts')  renderAccounts();
  if (tab==='items')     renderAdminItems();
  if (tab==='byperson')  renderAdminByPerson();
}

// ── NOTIFICATIONS ─────────────────────────────────────────────────
async function loadNotifications() {
  try {
    const list = await fetch('/api/notifications').then(r=>r.json()).catch(()=>[]);
    const count = list.length;
    const bell  = document.getElementById('notif-bell');
    const badge = document.getElementById('notif-count');
    if (bell)  bell.style.display = 'flex';
    if (badge) { badge.textContent = count; badge.style.display = count > 0 ? 'flex' : 'none'; }
    const nl = document.getElementById('notif-list');
    if (!nl) return;
    if (!list.length) { nl.innerHTML = '<div class="notif-empty">🎉 No overdue utang!</div>'; return; }
    nl.innerHTML = list.map(n => `
      <div class="notif-item ${n.read?'read':'unread'}">
        <div class="notif-icon">⚠️</div>
        <div class="notif-body">
          <div class="notif-title">Overdue: ${n.name}</div>
          <div class="notif-sub">₱${Number(n.amount).toFixed(2)} · ${n.daysOld} days pending · ${n.account}</div>
        </div>
        <button class="notif-dismiss" onclick="dismissNotif(${n.id})">✕</button>
      </div>`).join('');
  } catch {}
}
function toggleNotifPanel() {
  document.getElementById('notif-panel').classList.toggle('open');
  document.getElementById('notif-overlay').classList.toggle('open');
  loadNotifications();
}
async function markAllNotifsRead() {
  await fetch('/api/notifications/read-all', {method:'PUT'}).catch(()=>{});
  loadNotifications();
}
async function dismissNotif(id) {
  await fetch(`/api/notifications/${id}`, {method:'DELETE'}).catch(()=>{});
  loadNotifications();
}

// ── ANALYTICS ─────────────────────────────────────────────────────
async function renderAnalytics() {
  try {
    const d = await API.getAnalytics();

    // Stats row
    document.getElementById('analytics-stats').innerHTML = `
      <div class="stat-card"><div class="s-icon">💰</div><div class="s-num" style="font-size:1.3rem">₱${d.totalUtang.toFixed(0)}</div><div class="s-lbl">Total Utang</div></div>
      <div class="stat-card"><div class="s-icon">✅</div><div class="s-num" style="color:var(--success)">₱${d.paidUtang.toFixed(0)}</div><div class="s-lbl">Collected</div><div class="s-trend" style="color:var(--success)">${d.collectionRate}% rate</div></div>
      <div class="stat-card"><div class="s-icon">⏳</div><div class="s-num" style="color:var(--warning)">₱${d.pendingUtang.toFixed(0)}</div><div class="s-lbl">Pending</div><div class="s-trend">${d.pendingCount} records</div></div>
      <div class="stat-card"><div class="s-icon">📋</div><div class="s-num">${d.totalRecords}</div><div class="s-lbl">Total Records</div></div>`;

    // Monthly chart (bar chart using CSS)
    const maxVal = Math.max(...d.monthlyTrend.map(m=>m.total), 1);
    document.getElementById('monthly-chart').innerHTML = `
      <div class="bar-chart">
        ${d.monthlyTrend.map(m => `
          <div class="bar-col">
            <div class="bar-wrap">
              <div class="bar-paid" style="height:${Math.round((m.paid/maxVal)*120)}px" title="Paid: ₱${m.paid.toFixed(0)}"></div>
              <div class="bar-pending" style="height:${Math.round((m.pending/maxVal)*120)}px" title="Pending: ₱${m.pending.toFixed(0)}"></div>
            </div>
            <div class="bar-label">${m.month.split(' ')[0]}</div>
            <div class="bar-amt">₱${m.total >= 1000 ? (m.total/1000).toFixed(1)+'k' : m.total.toFixed(0)}</div>
          </div>`).join('')}
      </div>
      <div class="bar-legend">
        <span><span class="leg-dot" style="background:var(--success)"></span>Paid</span>
        <span><span class="leg-dot" style="background:var(--warning)"></span>Pending</span>
      </div>`;

    // Top debtors
    const td = document.getElementById('top-debtors-list');
    if (!d.topDebtors.length) { td.innerHTML = '<div class="empty-state"><p>No pending utang.</p></div>'; }
    else td.innerHTML = d.topDebtors.map((t,i) => `
      <div class="rank-row">
        <span class="rank-num">${['🥇','🥈','🥉','4️⃣','5️⃣'][i]||i+1}</span>
        <div class="rank-info"><div class="rank-name">${t.name}</div></div>
        <div class="rank-val" style="color:var(--warning)">₱${t.amount.toFixed(2)}</div>
      </div>`).join('');

    // Top items
    const ti = document.getElementById('top-items-list');
    if (!d.topItems.length) { ti.innerHTML = '<div class="empty-state"><p>No data yet.</p></div>'; }
    else ti.innerHTML = d.topItems.map((t,i) => `
      <div class="rank-row">
        <span class="rank-num">${i+1}</span>
        <div class="rank-info"><div class="rank-name">${t.emoji||'📦'} ${t.name}</div></div>
        <div class="rank-val">${t.count}x · <span style="color:var(--a2)">₱${t.revenue.toFixed(0)}</span></div>
      </div>`).join('');

    // Account breakdown
    document.getElementById('ac-breakdown-list').innerHTML = d.acBreakdown.map(a => `
      <div class="rank-row">
        <div class="u-av" style="width:28px;height:28px;font-size:.6rem;flex-shrink:0">${a.username.slice(0,2).toUpperCase()}</div>
        <div class="rank-info">
          <div class="rank-name">${a.username} <span class="badge ${a.role==='admin'?'b-admin':'b-user'}">${a.role}</span></div>
          <div style="font-size:.7rem;color:var(--text-muted)">${a.records} records</div>
        </div>
        <div class="rank-val"><span style="color:var(--warning)">₱${a.pending.toFixed(0)}</span> pending</div>
      </div>`).join('');
  } catch (e) {
    document.getElementById('analytics-stats').innerHTML = '<div style="color:var(--text-muted)">Failed to load analytics.</div>';
  }
}

// ── PROFILE ───────────────────────────────────────────────────────
async function renderProfile() {
  if (!cu) return;
  document.getElementById('profile-avatar').innerHTML = `
    <div class="profile-av-big">${cu.username.slice(0,2).toUpperCase()}</div>`;
  document.getElementById('profile-info').innerHTML = `
    <div class="profile-username">${cu.username}</div>
    <div style="margin-top:4px"><span class="badge ${cu.role==='admin'?'b-admin':'b-user'}">${cu.role==='admin'?'👑 Admin':'👤 User'}</span></div>`;
  try {
    const all = await API.getUtang({ account: cu.username });
    const total   = all.reduce((a,u)=>a+Number(u.amount),0);
    const pending = all.filter(u=>u.status==='pending').reduce((a,u)=>a+Number(u.amount),0);
    const paid    = all.filter(u=>u.status==='paid').reduce((a,u)=>a+Number(u.amount),0);
    document.getElementById('profile-stats').innerHTML = `
      <div class="ps-item"><div class="ps-num">${all.length}</div><div class="ps-lbl">Records</div></div>
      <div class="ps-item"><div class="ps-num" style="color:var(--warning)">₱${pending.toFixed(0)}</div><div class="ps-lbl">Pending</div></div>
      <div class="ps-item"><div class="ps-num" style="color:var(--success)">₱${paid.toFixed(0)}</div><div class="ps-lbl">Paid</div></div>
      <div class="ps-item"><div class="ps-num">₱${total.toFixed(0)}</div><div class="ps-lbl">Total</div></div>`;
  } catch {}
}
async function changePassword() {
  const old  = document.getElementById('cp-old').value;
  const nw   = document.getElementById('cp-new').value;
  const nw2  = document.getElementById('cp-new2').value;
  if (!old)               { showMsg('cp-msg','Enter current password.','error'); return; }
  if (!nw||nw.length<4)   { showMsg('cp-msg','New password min 4 chars.','error'); return; }
  if (nw !== nw2)         { showMsg('cp-msg','Passwords do not match.','error'); return; }
  try {
    await API.changePassword(cu.id, old, nw);
    ['cp-old','cp-new','cp-new2'].forEach(id => document.getElementById(id).value='');
    showMsg('cp-msg','✅ Password updated successfully!','success');
    toast('Password changed! 🔐', 'success');
  } catch (e) { showMsg('cp-msg', e.message, 'error'); }
}

// ── AUDIT LOG ─────────────────────────────────────────────────────
async function renderLogs() {
  const el    = document.getElementById('log-list');
  const empty = document.getElementById('log-empty');
  const search = document.getElementById('log-search')?.value.toLowerCase() || '';
  try {
    let logs = await API.getLogs();
    if (search) logs = logs.filter(l => l.action.toLowerCase().includes(search) || l.details.toLowerCase().includes(search) || l.by.toLowerCase().includes(search));
    if (!logs.length) { el.innerHTML=''; empty.style.display='block'; return; }
    empty.style.display='none';
    const icons = { LOGIN:'🔑', LOGOUT:'🚪', ITEM_ADD:'➕', ITEM_UPDATE:'✏️', ITEM_DELETE:'🗑', UTANG_ADD:'📋', UTANG_STATUS:'💳', UTANG_DELETE:'🗑', UTANG_BULK_PAID:'✅', USER_CREATE:'👤', USER_DELETE:'🗑', PASSWORD_CHANGE:'🔐' };
    el.innerHTML = logs.map(l => `
      <div class="log-row">
        <span class="log-icon">${icons[l.action]||'📝'}</span>
        <div class="log-body">
          <div class="log-action">${l.action.replace(/_/g,' ')}</div>
          <div class="log-detail">${l.details}</div>
        </div>
        <div class="log-meta">
          <div class="log-by">by ${l.by}</div>
          <div class="log-time">${l.date} ${l.time}</div>
        </div>
      </div>`).join('');
  } catch { el.innerHTML='<div class="empty-state"><p>Failed to load logs.</p></div>'; }
}
async function clearLogs() {
  if (!confirm('Clear all audit logs? This cannot be undone.')) return;
  await fetch('/api/logs', {method:'DELETE'});
  toast('Audit log cleared 🗑', 'info');
  renderLogs();
}

// ── BANNER ────────────────────────────────────────────────────────
async function saveBanner() {
  const msg   = document.getElementById('sett-banner').value.trim();
  const style = document.getElementById('sett-banner-style').value;
  await API.saveSettings({ banner: msg, bannerStyle: style, bannerActive: !!msg });
  renderShopBanner({ banner: msg, bannerStyle: style, bannerActive: !!msg });
  showMsg('banner-msg', msg ? '✅ Banner saved!' : '✅ Banner cleared!', 'success');
  toast('Banner updated! 📢', 'success');
}
async function clearBanner() {
  await API.saveSettings({ banner: '', bannerActive: false });
  renderShopBanner({ banner: '', bannerActive: false });
  document.getElementById('sett-banner').value = '';
  showMsg('banner-msg', 'Banner cleared.', 'success');
}
function renderShopBanner(s) {
  const wrap = document.getElementById('shop-banner-wrap');
  const el   = document.getElementById('shop-banner-el');
  if (!wrap || !el) return;
  if (s.banner && s.bannerActive) {
    el.className = `shop-banner banner-${s.bannerStyle||'info'}`;
    el.innerHTML = `<span class="banner-icon">${{info:'ℹ️',success:'✅',warning:'⚠️',promo:'🎉'}[s.bannerStyle||'info']}</span><span>${s.banner}</span>`;
    wrap.style.display = 'block';
  } else { wrap.style.display = 'none'; }
}

// ── OVERDUE SETTINGS ──────────────────────────────────────────────
async function saveOverdue() {
  const days = parseInt(document.getElementById('sett-overdue').value) || 7;
  await API.saveSettings({ overduedays: days });
  showMsg('overdue-msg', `✅ Overdue threshold set to ${days} days!`, 'success');
}

// ── EXPORT ────────────────────────────────────────────────────────
function exportUtang() {
  const url = '/api/export/utang';
  const a = document.createElement('a'); a.href = url; a.download = 'utang_export.csv';
  document.body.appendChild(a); a.click(); a.remove();
  toast('Exporting CSV... 📥', 'success');
}

// ── PWA INSTALL ───────────────────────────────────────────────────
let _pwaPrompt = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault(); _pwaPrompt = e;
  const btn = document.getElementById('pwa-install-btn');
  const st  = document.getElementById('pwa-status');
  if (btn) btn.style.display = 'inline-flex';
  if (st)  st.textContent = 'Tap the button above to install JamFamily SHOP on your device.';
});
window.addEventListener('appinstalled', () => {
  const st = document.getElementById('pwa-status');
  if (st) st.innerHTML = '✅ App installed successfully!';
  toast('JamFamily SHOP installed! 📱', 'success');
  _pwaPrompt = null;
});
async function installPWA() {
  if (!_pwaPrompt) { toast('Already installed or not supported on this browser.', 'info'); return; }
  _pwaPrompt.prompt();
  const { outcome } = await _pwaPrompt.userChoice;
  if (outcome === 'accepted') toast('Installing JamFamily SHOP... 📱', 'success');
  _pwaPrompt = null;
}

// ── SETTINGS PAGE ─────────────────────────────────────────────────
async function initSettingsPage() {
  try {
    const s = await API.getSettings();
    applyShopInfo(s);
    setTheme(s.theme || 'gold');
    const b  = document.getElementById('sett-banner');     if (b)  b.value  = s.banner || '';
    const bs = document.getElementById('sett-banner-style');if (bs) bs.value = s.bannerStyle || 'info';
    const od = document.getElementById('sett-overdue');    if (od) od.value = s.overduedays || 7;
  } catch {}
  // PWA status
  const st = document.getElementById('pwa-status');
  if (st) {
    if (window.matchMedia('(display-mode: standalone)').matches) st.innerHTML = '✅ Already installed as an app!';
    else if (_pwaPrompt) { document.getElementById('pwa-install-btn').style.display='inline-flex'; st.textContent='Tap Install to add to home screen.'; }
    else st.textContent = 'Open in Chrome/Safari and use "Add to Home Screen" to install.';
  }
  updateDBStatus();
}

// ── BOOT ──────────────────────────────────────────────────────────
(async function init() {
  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(()=>{});
  }
  try {
    const s = await API.getSettings();
    applyShopInfo(s);
    setTheme(s.theme || 'gold');
    renderShopBanner(s);
  } catch {
    applyShopInfo({ shopName:'JamFamily SHOP', tagline:'Your trusted neighborhood shop' });
    setTheme('gold');
  }
  _allItems = await API.getItems().catch(() => []);
  updateNav();
  goPage('shop');
})();
document.addEventListener('DOMContentLoaded', () => {
  const area = document.getElementById('photo-upload-area');
  if (!area) return;
  area.addEventListener('dragover', e => { e.preventDefault(); area.classList.add('drag-over'); });
  area.addEventListener('dragleave', () => area.classList.remove('drag-over'));
  area.addEventListener('drop', e => {
    e.preventDefault(); area.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (!file) return;
    // simulate file input change
    const dt = new DataTransfer(); dt.items.add(file);
    document.getElementById('im-photo-file').files = dt.files;
    handlePhotoSelect({ target: { files: [file] } });
  });
});

// ── KEYBOARD / CLOSE ──────────────────────────────────────────────
document.getElementById('login-pass').addEventListener('keydown', e => { if (e.key==='Enter') doLogin(); });
document.getElementById('login-user').addEventListener('keydown', e => { if (e.key==='Enter') doLogin(); });
document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', function(e) { if (e.target===this) closeModal(this.id); });
});

// BOOT_PLACEHOLDER

// ══════════════════════════════════════════
// ALL 10 NEW FEATURES v4.0
// ══════════════════════════════════════════

// ── PRESETS ──────────────────────────────────────────────────────
async function loadPresetChips() {
  const presets = await API.getPresets().catch(()=>[]);
  const el = document.getElementById('preset-chips'); if (!el) return;
  el.innerHTML = !presets.length
    ? '<span style="font-size:.72rem;color:var(--text-muted)">No presets yet</span>'
    : presets.map(p=>`<button class="preset-chip" onclick="applyPreset(${p.id})">${p.icon||'⚡'} ${p.name} <span style="color:var(--a2)">₱${Number(p.total).toFixed(0)}</span></button>`).join('');
}
async function applyPreset(id) {
  const presets = await API.getPresets().catch(()=>[]);
  const p = presets.find(x=>x.id===id); if(!p||!p.items) return;
  document.getElementById('utang-item-rows').innerHTML=''; rowC=0;
  p.items.forEach(item=>addItemRow(item.id,item.qty));
  toast(`Preset "${p.name}" loaded! ⚡`,'success');
}
async function savePreset() {
  const rows=getRows(); if(!rows.length){toast('Add items first!','error');return;}
  const name=prompt('Preset name (e.g. "Juan usual"):'); if(!name) return;
  const total=rows.reduce((s,r)=>s+r.sub,0);
  const icon=prompt('Emoji icon (optional):')||'⚡';
  await API.addPreset({name,icon,items:rows,total}).catch(()=>{});
  toast(`Preset "${name}" saved! 💾`,'success');
  loadPresetChips();
}
async function renderAdminPresets() {
  const el=document.getElementById('admin-presets-list');
  const empty=document.getElementById('admin-presets-empty');
  const presets=await API.getPresets().catch(()=>[]);
  if(!presets.length){if(el)el.innerHTML='';if(empty)empty.style.display='block';return;}
  if(empty)empty.style.display='none';
  if(!el) return;
  el.innerHTML=presets.map(p=>`
    <div class="item-row">
      <div class="item-thumb" style="font-size:1.4rem;display:flex;align-items:center;justify-content:center">${p.icon||'⚡'}</div>
      <div class="item-details">
        <div class="item-name">${p.name}</div>
        <div class="item-meta">${(p.items||[]).map(i=>`${i.emoji||''}${i.name}×${i.qty}`).join(' · ')} · <span style="color:var(--a2)">₱${Number(p.total||0).toFixed(2)}</span></div>
      </div>
      <div class="item-actions"><button class="btn btn-sm btn-danger" onclick="deletePreset(${p.id})">🗑 Delete</button></div>
    </div>`).join('');
}
async function deletePreset(id){
  if(!confirm('Delete this preset?'))return;
  await API.deletePreset(id); toast('Preset deleted 🗑','info'); renderAdminPresets();
}

// ── PAYMENT MODAL (full + partial + method) ───────────────────────
let _payType='full';
function setPayType(type){
  _payType=type;
  const fb=document.getElementById('pay-full-btn');
  const pb=document.getElementById('pay-partial-btn');
  const pw=document.getElementById('partial-amt-wrap');
  if(fb)fb.classList.toggle('active',type==='full');
  if(pb)pb.classList.toggle('active',type==='partial');
  if(pw)pw.style.display=type==='partial'?'block':'none';
}
function selectPayMethod(btn){
  document.querySelectorAll('.pay-meth-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}
async function openPaymentModal(id, currentStatus){
  _pendingMarkPaidId=id; _pendingMarkPaidStatus=currentStatus;
  if(currentStatus==='paid'){confirmMarkPaid();return;}
  _payType='full'; setPayType('full');
  const pnEl=document.getElementById('payment-note'); if(pnEl)pnEl.value='';
  const paEl=document.getElementById('payment-partial-amt'); if(paEl)paEl.value='';
  try{
    const s=await API.getSettings();
    const methods=s.paymentMethods||['Cash','GCash','PayMaya','Other'];
    const el=document.getElementById('pay-method-btns');
    if(el){el.innerHTML=methods.map(m=>`<button class="pay-meth-btn" onclick="selectPayMethod(this)">${m}</button>`).join('');el.firstChild?.classList.add('active');}
  }catch{}
  openModal('payment-modal');
}
async function confirmMarkPaid(){
  const id=_pendingMarkPaidId, cur=_pendingMarkPaidStatus;
  const note=document.getElementById('payment-note')?.value.trim()||'';
  const newStatus=cur==='paid'?'pending':'paid';
  const selMethod=document.querySelector('.pay-meth-btn.active')?.textContent||'Cash';
  const partialAmt=parseFloat(document.getElementById('payment-partial-amt')?.value)||0;
  closeModal('payment-modal');
  try{
    if(_payType==='partial'&&partialAmt>0){
      await API.updateUtang(id,{partialAmount:partialAmt,paymentMethod:selMethod,paymentNote:note,changedBy:cu.username});
      toast(`Partial ₱${partialAmt.toFixed(2)} recorded via ${selMethod}! 💳`,'success');
    } else {
      await API.updateUtang(id,{status:newStatus,paymentMethod:selMethod,paymentNote:note,changedBy:cu.username});
      toast(newStatus==='paid'?`✅ Marked paid via ${selMethod}!`:'↩ Marked as pending',newStatus==='paid'?'success':'info');
    }
    refreshCurrentView();
    if(cu.role!=='admin')renderUserBanner();
  }catch(e){toast(e.message,'error');}
}

// ── SMS TEMPLATE ──────────────────────────────────────────────────
async function openSMSModal(u){
  try{
    const s=await API.getSettings();
    const shop=s.shopName||'JamFamily SHOP';
    const balance=(Number(u.amount)-Number(u.paidAmount||0)).toFixed(2);
    const due=u.dueDate?` Please pay before ${new Date(u.dueDate).toLocaleDateString('en-PH')}.`:'';
    const msg=`Hi ${u.name}! 👋\n\nYou have a pending balance of ₱${balance} at ${shop}.${due}\n\nKindly settle your account at your earliest convenience. Salamat po! 🙏\n\n📍 ${s.location||'Hubo, Pasacao, Camarines Sur'}`;
    const el=document.getElementById('sms-text'); if(el)el.textContent=msg;
    openModal('sms-modal');
  }catch(e){toast('Could not generate SMS','error');}
}
function copySMS(){
  const txt=document.getElementById('sms-text')?.textContent||'';
  if(navigator.clipboard){navigator.clipboard.writeText(txt).then(()=>toast('Copied! 📋','success')).catch(()=>_fallbackCopy(txt));}
  else _fallbackCopy(txt);
}
function _fallbackCopy(txt){const ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();toast('Copied! 📋','success');}
function openSMS(){const txt=encodeURIComponent(document.getElementById('sms-text')?.textContent||'');window.open(`sms:?body=${txt}`,'_blank');}

// ── STOCK COUNT in admin items ────────────────────────────────────
async function renderAdminItems(){
  const el=document.getElementById('admin-items-list');
  try{
    const items=await API.getItems();
    if(!items.length){el.innerHTML='<div class="empty-state"><div class="empty-icon">📦</div><p>No items.</p></div>';return;}
    el.innerHTML=items.map(i=>{
      const hasStock=i.stockCount!==null&&i.stockCount!==undefined;
      const isLow=hasStock&&i.stockCount<=(i.lowStockAlert||5)&&i.stock==='in';
      return `<div class="item-row${isLow?' item-low-stock':''}">
        <div class="item-thumb">
          ${i.photo?`<img src="${i.photo}" alt="${i.name}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`:'' }
          <span class="item-emoji" style="${i.photo?'display:none':'display:flex'}">${i.emoji||'📦'}</span>
        </div>
        <div class="item-details">
          <div class="item-name">${i.name}${isLow?' <span class="low-stock-badge">⚠️ Low</span>':''}</div>
          <div class="item-meta">₱${Number(i.price).toFixed(2)} · <span class="item-cat-badge">${i.category||'—'}</span> · <span style="color:${i.stock==='in'?'var(--success)':'var(--danger)'}">${i.stock==='in'?'May Stock':'Wala na'}</span>${hasStock?` · <strong style="color:${isLow?'var(--danger)':'var(--text-main)'}">${i.stockCount} left</strong>`:''}</div>
        </div>
        <div class="item-actions">
          ${hasStock?`<div class="stock-adj"><button onclick="adjStock(${i.id},-1)" class="btn btn-sm btn-danger" style="padding:4px 8px">−</button><span style="font-weight:700;min-width:28px;text-align:center">${i.stockCount}</span><button onclick="adjStock(${i.id},1)" class="btn btn-sm btn-success" style="padding:4px 8px">+</button></div>`:''}
          <button class="btn btn-sm ${i.stock==='in'?'btn-danger':'btn-success'}" onclick="toggleStock(${i.id},'${i.stock}')">${i.stock==='in'?'Set Wala':'Set Stock'}</button>
          <button class="btn btn-sm btn-secondary" onclick="openItemModal(${i.id})">✏️</button>
          <button class="btn btn-sm btn-danger" onclick="delItem(${i.id})">🗑</button>
        </div>
      </div>`;
    }).join('');
  }catch{el.innerHTML='<div class="empty-state"><p>Failed to load.</p></div>';}
}
async function adjStock(id,delta){
  const items=await API.getItems().catch(()=>[]);
  const item=items.find(i=>i.id===id);if(!item)return;
  const newCount=Math.max(0,(item.stockCount||0)+delta);
  await API.updateItem(id,{stockCount:newCount,stock:newCount>0?'in':'out'});
  _allItems=await API.getItems().catch(()=>_allItems);
  renderAdminItems();
}

// ── LOGO UPLOAD ───────────────────────────────────────────────────
async function uploadLogo(event){
  const file=event.target.files[0];if(!file)return;
  try{
    const res=await API.uploadLogo(file);
    const img=document.getElementById('logo-preview-img');
    const ph=document.getElementById('logo-placeholder');
    if(img){img.src=res.url;img.style.display='block';}
    if(ph)ph.style.display='none';
    applyLogo(res.url);
    showMsg('logo-msg','✅ Logo uploaded!','success');
    toast('Logo updated! 🖼️','success');
  }catch(e){showMsg('logo-msg',e.message,'error');}
}
function applyLogo(url){
  if(!url)return;
  const brand=document.getElementById('nav-brand-text');
  if(brand&&!brand.querySelector('img')){
    brand.insertAdjacentHTML('afterbegin',`<img src="${url}" alt="Logo" style="height:26px;width:auto;object-fit:contain;vertical-align:middle;margin-right:6px" onerror="this.remove()">`);
  }
}
async function removeLogo(){
  await API.saveSettings({logoUrl:''});
  const img=document.getElementById('logo-preview-img');const ph=document.getElementById('logo-placeholder');
  if(img){img.src='';img.style.display='none';}if(ph)ph.style.display='block';
  const brand=document.getElementById('nav-brand-text');
  brand?.querySelector('img')?.remove();
  showMsg('logo-msg','Logo removed.','success');
}

// ── LANGUAGE ──────────────────────────────────────────────────────
const LANGS={
  en:{home:'🏠 Home',shop:'🛒 Shop',utang:'📋 Utang',admin:'⚙️ Admin',settings:'🔧 Settings',analytics:'📊 Analytics',profile:'👤 Profile',calendar:'🗓️ Calendar',login:'🔑 Login'},
  fil:{home:'🏠 Tahanan',shop:'🛒 Tindahan',utang:'📋 Utang',admin:'⚙️ Admin',settings:'🔧 Mga Setting',analytics:'📊 Ulat',profile:'👤 Profile Ko',calendar:'🗓️ Kalendaryo',login:'🔑 Mag-login'}
};
function setLang(lang){
  API.saveSettings({language:lang}).catch(()=>{});
  const L=LANGS[lang]||LANGS.en;
  const map={'nb-home':L.home,'nb-shop':L.shop,'nb-utang':L.utang,'nb-admin':L.admin,'nb-settings':L.settings,'nb-analytics':L.analytics,'nb-login-btn':L.login};
  Object.entries(map).forEach(([id,txt])=>{const e=document.getElementById(id);if(e)e.textContent=txt;});
  document.querySelectorAll('.lang-btn').forEach(b=>b.classList.remove('active'));
  const lb=document.getElementById('lang-'+lang);if(lb)lb.classList.add('active');
  const ls=document.getElementById('lang-status');if(ls)ls.textContent=`Current: ${lang==='fil'?'Filipino':'English'}`;
  toast(`Language: ${lang==='fil'?'Filipino 🇵🇭':'English 🇺🇸'}`,'info');
}

// ── PAYMENT METHODS CONFIG ────────────────────────────────────────
async function renderPaymentMethodsConfig(){
  const s=await API.getSettings().catch(()=>({}));
  const methods=s.paymentMethods||['Cash','GCash','PayMaya','Other'];
  const el=document.getElementById('payment-methods-config');if(!el)return;
  el.innerHTML=methods.map((m,i)=>`
    <div style="display:flex;align-items:center;gap:.4rem;padding:.3rem 0;border-bottom:1px solid rgba(255,255,255,.04)">
      <span style="flex:1;font-size:.82rem">💳 ${m}</span>
      <button class="btn btn-sm btn-danger" onclick="removePaymentMethod(${i})" style="padding:3px 8px">✕</button>
    </div>`).join('');
}
async function addPaymentMethod(){
  const input=document.getElementById('new-payment-method');
  const val=input?.value.trim();if(!val)return;
  const s=await API.getSettings().catch(()=>({}));
  const methods=s.paymentMethods||['Cash','GCash','PayMaya','Other'];
  if(methods.includes(val)){showMsg('pm-msg','Already exists.','error');return;}
  methods.push(val);await API.saveSettings({paymentMethods:methods});
  input.value='';renderPaymentMethodsConfig();showMsg('pm-msg',`✅ "${val}" added!`,'success');
}
async function removePaymentMethod(idx){
  const s=await API.getSettings().catch(()=>({}));
  const methods=s.paymentMethods||[];methods.splice(idx,1);
  await API.saveSettings({paymentMethods:methods});renderPaymentMethodsConfig();
}

// ── CALENDAR PAGE ─────────────────────────────────────────────────
let calYear=new Date().getFullYear(),calMonth=new Date().getMonth()+1;
async function renderCalendar(){
  const lbl=document.getElementById('cal-month-label');
  if(lbl)lbl.textContent=new Date(calYear,calMonth-1,1).toLocaleDateString('en-PH',{month:'long',year:'numeric'});
  const data=await API.getCalendar(calYear,calMonth).catch(()=>[]);
  const calMap={};data.forEach(x=>calMap[x.date]=x);
  const grid=document.getElementById('calendar-grid');if(!grid)return;
  const firstDay=new Date(calYear,calMonth-1,1).getDay();
  const daysInMonth=new Date(calYear,calMonth,0).getDate();
  const todayStr=new Date().toISOString().split('T')[0];
  let html='<div class="cal-grid">';
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>html+=`<div class="cal-day-hdr">${d}</div>`);
  for(let i=0;i<firstDay;i++)html+=`<div class="cal-cell empty"></div>`;
  for(let day=1;day<=daysInMonth;day++){
    const ds=`${calYear}-${String(calMonth).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const info=calMap[ds];const isToday=ds===todayStr;
    html+=`<div class="cal-cell${info?' has-data':''}${isToday?' is-today':''}" onclick="showCalDay('${ds}')">
      <div class="cal-day-num">${day}</div>
      ${info?`<div class="cal-day-count">${info.count}</div><div class="cal-day-amt">₱${info.amount>=1000?(info.amount/1000).toFixed(1)+'k':info.amount.toFixed(0)}</div>`:''}
    </div>`;
  }
  html+='</div>';grid.innerHTML=html;
}
function calNav(dir){
  calMonth+=dir;if(calMonth>12){calMonth=1;calYear++;}if(calMonth<1){calMonth=12;calYear--;}
  renderCalendar();
}
async function showCalDay(dateStr){
  const det=document.getElementById('calendar-detail');if(det)det.style.display='block';
  const ttl=document.getElementById('cal-detail-title');
  if(ttl)ttl.textContent=`Records — ${new Date(dateStr+'T12:00:00').toLocaleDateString('en-PH',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}`;
  const list=await API.getUtang({}).catch(()=>[]);
  const localDate=new Date(dateStr+'T12:00:00').toLocaleDateString('en-PH');
  const dayRecords=list.filter(u=>(u.dateISO||'').startsWith(dateStr)||u.date===localDate);
  const el=document.getElementById('cal-detail-records');if(!el)return;
  if(!dayRecords.length){el.innerHTML='<div style="color:var(--text-muted);font-size:.8rem;padding:.5rem 0">No records on this day.</div>';return;}
  el.innerHTML=dayRecords.map(u=>utangCardHTML(u,cu?.role==='admin')).join('');
}

// ── ANALYTICS with payment methods + mini calendar ────────────────
async function renderAnalytics(){
  try{
    const d=await API.getAnalytics();
    document.getElementById('analytics-stats').innerHTML=`
      <div class="stat-card"><div class="s-icon">💰</div><div class="s-num" style="font-size:1.3rem">₱${d.totalUtang.toFixed(0)}</div><div class="s-lbl">Total Utang</div></div>
      <div class="stat-card"><div class="s-icon">✅</div><div class="s-num" style="color:var(--success)">₱${d.paidUtang.toFixed(0)}</div><div class="s-lbl">Collected</div><div class="s-trend" style="color:var(--success)">${d.collectionRate}% rate</div></div>
      <div class="stat-card"><div class="s-icon">⏳</div><div class="s-num" style="color:var(--warning)">₱${d.pendingUtang.toFixed(0)}</div><div class="s-lbl">Pending</div><div class="s-trend">${d.pendingCount} records</div></div>
      <div class="stat-card"><div class="s-icon">📋</div><div class="s-num">${d.totalRecords}</div><div class="s-lbl">Records</div></div>`;
    const maxVal=Math.max(...d.monthlyTrend.map(m=>m.total),1);
    document.getElementById('monthly-chart').innerHTML=`
      <div class="bar-chart">${d.monthlyTrend.map(m=>`
        <div class="bar-col"><div class="bar-wrap">
          <div class="bar-paid" style="height:${Math.round((m.paid/maxVal)*120)}px" title="Paid: ₱${m.paid.toFixed(0)}"></div>
          <div class="bar-pending" style="height:${Math.round((m.pending/maxVal)*120)}px" title="Pending: ₱${m.pending.toFixed(0)}"></div>
        </div><div class="bar-label">${m.month.split(' ')[0]}</div><div class="bar-amt">₱${m.total>=1000?(m.total/1000).toFixed(1)+'k':m.total.toFixed(0)}</div></div>`).join('')}
      </div>
      <div class="bar-legend"><span><span class="leg-dot" style="background:var(--success)"></span>Paid</span><span><span class="leg-dot" style="background:var(--warning)"></span>Pending</span></div>`;
    document.getElementById('top-debtors-list').innerHTML=!d.topDebtors.length?'<div class="empty-state"><p>No pending utang.</p></div>':
      d.topDebtors.map((t,i)=>`<div class="rank-row"><span class="rank-num">${['🥇','🥈','🥉','4️⃣','5️⃣'][i]||i+1}</span><div class="rank-info"><div class="rank-name">${t.name}</div></div><div class="rank-val" style="color:var(--warning)">₱${t.amount.toFixed(2)}</div></div>`).join('');
    document.getElementById('top-items-list').innerHTML=!d.topItems.length?'<div class="empty-state"><p>No data yet.</p></div>':
      d.topItems.map((t,i)=>`<div class="rank-row"><span class="rank-num">${i+1}</span><div class="rank-info"><div class="rank-name">${t.emoji||'📦'} ${t.name}</div></div><div class="rank-val">${t.count}x · <span style="color:var(--a2)">₱${t.revenue.toFixed(0)}</span></div></div>`).join('');
    document.getElementById('ac-breakdown-list').innerHTML=d.acBreakdown.map(a=>`
      <div class="rank-row"><div class="u-av" style="width:28px;height:28px;font-size:.6rem;flex-shrink:0">${a.username.slice(0,2).toUpperCase()}</div>
      <div class="rank-info"><div class="rank-name">${a.username} <span class="badge ${a.role==='admin'?'b-admin':'b-user'}">${a.role}</span></div><div style="font-size:.7rem;color:var(--text-muted)">${a.records} records</div></div>
      <div class="rank-val"><span style="color:var(--warning)">₱${a.pending.toFixed(0)}</span> pending</div></div>`).join('');
    const pm=document.getElementById('payment-methods-list');
    const methods=d.paymentMethods||[];
    if(pm)pm.innerHTML=!methods.length?'<div style="color:var(--text-muted);font-size:.8rem;padding:.5rem">No payment data yet.</div>':
      methods.map(m=>`<div class="rank-row"><span class="rank-num">💳</span><div class="rank-info"><div class="rank-name">${m.method}</div></div><div class="rank-val" style="color:var(--success)">₱${m.amount.toFixed(0)}</div></div>`).join('');
    // mini calendar heatmap
    const calEl=document.getElementById('analytics-calendar');
    if(calEl&&d.calData){
      const days=[]; const today=new Date();
      for(let i=34;i>=0;i--){const dd=new Date(today);dd.setDate(dd.getDate()-i);days.push(dd.toISOString().split('T')[0]);}
      const maxC=Math.max(...Object.values(d.calData).map(x=>x.count),1);
      calEl.innerHTML=`<div class="mini-cal-grid">${days.map(date=>{const info=d.calData[date];const intensity=info?Math.ceil((info.count/maxC)*4):0;return`<div class="mini-cal-cell intensity-${intensity}" title="${date}${info?' · '+info.count+' records · ₱'+info.amount.toFixed(0):''}" onclick="goPage('calendar')"></div>`;}).join('')}</div>
      <div style="font-size:.65rem;color:var(--text-muted);margin-top:.4rem;display:flex;justify-content:space-between"><span>35 days ago</span><span>Today</span></div>`;
    }
  }catch(e){const el=document.getElementById('analytics-stats');if(el)el.innerHTML='<div style="color:var(--text-muted)">Failed to load analytics.</div>';}
}

// ── UTANG CARD with due date, balance, progress, SMS ─────────────
function utangCardHTML(u, canAct){
  const initials=u.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const isOverdue=u.status==='pending'&&u.dateISO&&(Date.now()-new Date(u.dateISO))>7*86400000;
  const balance=Number(u.amount)-Number(u.paidAmount||0);
  const hasDue=u.dueDate;
  const daysLeft=hasDue?Math.ceil((new Date(u.dueDate)-Date.now())/86400000):null;
  const dueClass=daysLeft!==null?(daysLeft<0?'due-overdue':daysLeft<=2?'due-soon':'due-ok'):'';
  const lastH=u.history?.length?u.history[u.history.length-1]:null;
  const pct=u.paidAmount>0?Math.min(100,Math.round((u.paidAmount/u.amount)*100)):0;
  const uJson=JSON.stringify(u).replace(/"/g,'&quot;');
  return `<div class="utang-card ${u.status==='paid'?'is-paid':''} ${isOverdue?'is-overdue':''}" id="uc-${u.id}">
    <div class="uc-top">
      <div class="uc-av">${initials}</div>
      <div class="uc-info">
        <div class="uc-name">${u.name}${isOverdue?' <span class="overdue-badge">⚠️ Overdue</span>':''}</div>
        <div class="uc-note">${u.note?`📝 ${u.note} `:''}${hasDue?`<span class="due-badge ${dueClass}">📅 ${daysLeft<0?Math.abs(daysLeft)+'d overdue':daysLeft===0?'Due today':daysLeft+'d left'}</span>`:''}</div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div class="uc-amount">₱${balance.toFixed(2)}</div>
        ${u.paidAmount>0?`<div style="font-size:.65rem;color:var(--success)">+₱${Number(u.paidAmount).toFixed(0)} paid</div>`:''}
      </div>
    </div>
    ${pct>0&&u.status!=='paid'?`<div class="progress-bar-wrap"><div class="progress-bar-fill" style="width:${pct}%"></div><span class="progress-label">${pct}% paid</span></div>`:''}
    <div class="uc-items">
      ${(u.items||[{name:u.item,emoji:'📦',qty:''}]).map(r=>`<span class="uc-item-tag">${r.emoji||'📦'} ${r.name}${r.qty?`<span class="qty">×${r.qty}</span>`:''}</span>`).join('')}
    </div>
    ${lastH?`<div class="uc-history">💳 ${lastH.to==='paid'?'Paid':'Updated'} ${lastH.date} by ${lastH.by}${lastH.note?' · '+lastH.note:''}${lastH.method?' via '+lastH.method:''}</div>`:''}
    <div class="uc-footer">
      <div class="uc-meta">
        <span class="badge ${u.status==='paid'?'b-paid':'b-pending'}">${u.status==='paid'?'✅ Paid':'⏳ Pending'}</span>
        <span class="badge b-user">👤 ${u.account||u.by}</span>
        <span style="font-size:.63rem;color:var(--text-muted)">📅 ${u.date}</span>
      </div>
      <div class="uc-actions">
        ${canAct?`
          <button class="btn btn-sm ${u.status==='paid'?'btn-warn':'btn-success'}" onclick="openPaymentModal(${u.id},'${u.status}')">${u.status==='paid'?'↩ Undo':'✓ Paid'}</button>
          <button class="btn btn-sm btn-secondary" onclick='openSMSModal(${JSON.stringify(u).replace(/\\/g,"\\\\").replace(/'/g,"\\'")})' title="SMS">💬</button>
          <button class="btn btn-sm btn-secondary" onclick="printReceipt(${u.id},&quot;${uJson}&quot;)">🧾</button>
          <button class="btn btn-sm btn-danger" onclick="delUtang(${u.id})">🗑</button>
        `:`<button class="btn btn-sm btn-secondary" onclick="printReceipt(${u.id},&quot;${uJson}&quot;)">🧾</button>`}
      </div>
    </div>
  </div>`;
}

// ── UPDATE goPage ─────────────────────────────────────────────────
function goPage(pg){
  const prot=['utang','admin','home','settings','analytics','profile','log','calendar'];
  if(!cu&&prot.includes(pg)){openModal('login-modal');return;}
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nav-btn,.bnav-btn').forEach(b=>b.classList.remove('active'));
  ['page-','nb-','bnb-'].forEach(pre=>{const e=document.getElementById(pre+pg);if(e)e.classList.add('active');});
  window.scrollTo({top:0,behavior:'smooth'});
  if(pg==='home')renderHome();
  if(pg==='shop'){renderShop();loadPresetChips();}
  if(pg==='utang'){initUtangPage();renderUtangCards();}
  if(pg==='admin'){renderAdminItems();renderAccounts();renderAdminUtang();renderAdminByPerson();renderAdminPresets();}
  if(pg==='analytics')renderAnalytics();
  if(pg==='profile')renderProfile();
  if(pg==='log')renderLogs();
  if(pg==='settings')initSettingsPage();
  if(pg==='calendar')renderCalendar();
}

// ── UPDATE adminTab ───────────────────────────────────────────────
function adminTab(tab,btn){
  document.querySelectorAll('.admin-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.admin-section').forEach(s=>s.classList.remove('active'));
  if(btn)btn.classList.add('active');
  document.getElementById('asec-'+tab)?.classList.add('active');
  adminAcF=null;
  if(tab==='allutang')renderAdminUtang();
  if(tab==='accounts')renderAccounts();
  if(tab==='items')renderAdminItems();
  if(tab==='byperson')renderAdminByPerson();
  if(tab==='presets')renderAdminPresets();
}

// ── UPDATE initSettingsPage ───────────────────────────────────────
async function initSettingsPage(){
  try{
    const s=await API.getSettings();
    applyShopInfo(s);setTheme(s.theme||'gold');
    const b=document.getElementById('sett-banner');if(b)b.value=s.banner||'';
    const bs=document.getElementById('sett-banner-style');if(bs)bs.value=s.bannerStyle||'info';
    const od=document.getElementById('sett-overdue');if(od)od.value=s.overduedays||7;
    if(s.logoUrl){const img=document.getElementById('logo-preview-img');const ph=document.getElementById('logo-placeholder');if(img){img.src=s.logoUrl;img.style.display='block';}if(ph)ph.style.display='none';}
    const L=s.language||'en';document.querySelectorAll('.lang-btn').forEach(b=>b.classList.remove('active'));
    const lb=document.getElementById('lang-'+L);if(lb)lb.classList.add('active');
    const ls=document.getElementById('lang-status');if(ls)ls.textContent=`Current: ${L==='fil'?'Filipino':'English'}`;
    renderPaymentMethodsConfig();
  }catch{}
  const st=document.getElementById('pwa-status');
  if(st){if(window.matchMedia('(display-mode: standalone)').matches)st.innerHTML='✅ Already installed!';else if(_pwaPrompt){document.getElementById('pwa-install-btn').style.display='inline-flex';st.textContent='Tap Install to add to home screen.';}else st.textContent='Open in Chrome/Safari → Add to Home Screen.';}
  updateDBStatus();
}

// ── KEYBOARD SHORTCUTS ────────────────────────────────────────────
document.getElementById('login-pass')?.addEventListener('keydown',e=>{if(e.key==='Enter')doLogin();});
document.getElementById('login-user')?.addEventListener('keydown',e=>{if(e.key==='Enter')doLogin();});
document.querySelectorAll('.modal-overlay').forEach(m=>{m.addEventListener('click',function(e){if(e.target===this)closeModal(this.id);});});

// ── DRAG & DROP photo ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded',()=>{
  const area=document.getElementById('photo-upload-area');if(!area)return;
  area.addEventListener('dragover',e=>{e.preventDefault();area.classList.add('drag-over');});
  area.addEventListener('dragleave',()=>area.classList.remove('drag-over'));
  area.addEventListener('drop',e=>{e.preventDefault();area.classList.remove('drag-over');const file=e.dataTransfer.files[0];if(!file)return;const dt=new DataTransfer();dt.items.add(file);document.getElementById('im-photo-file').files=dt.files;handlePhotoSelect({target:{files:[file]}});});
});

// ── BOOT ──────────────────────────────────────────────────────────
(async function init(){
  if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
  try{
    const s=await API.getSettings();
    applyShopInfo(s);setTheme(s.theme||'gold');renderShopBanner(s);
    if(s.logoUrl)applyLogo(s.logoUrl);
    if(s.language)setLang(s.language);
  }catch{
    applyShopInfo({shopName:'JamFamily SHOP',tagline:'Your trusted neighborhood shop'});
    setTheme('gold');
  }
  _allItems=await API.getItems().catch(()=>[]);
  updateNav();goPage('shop');
})();
