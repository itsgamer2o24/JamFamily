# 🌙 JamFamily SHOP v2.0

A full-stack neighborhood shop management system with JSON file database.

---

## 📁 Project Structure

```
jamfamily/
├── server.js              ← Node.js/Express backend
├── package.json           ← Dependencies
├── data/
│   ├── items.json         ← 🛍 Shop items database
│   ├── utang.json         ← 📋 Utang records database
│   ├── users.json         ← 👤 User accounts database
│   └── settings.json      ← ⚙️ Shop settings
└── public/
    ├── index.html         ← Main frontend page
    ├── css/
    │   └── style.css      ← All styles
    └── js/
        ├── bg.js          ← Animated night sky background
        ├── api.js         ← API layer (server + offline fallback)
        └── app.js         ← Full application logic
```

---

## 🚀 How to Run

### Option 1 — With Node.js Backend (Full Database Mode)
```bash
# 1. Install Node.js from https://nodejs.org
# 2. Open terminal in this folder
cd jamfamily
npm install
node server.js
# 3. Open browser: http://localhost:3000
```

### Option 2 — Without Backend (Offline/localStorage Mode)
Just open `public/index.html` directly in your browser.
Data will be saved in the browser's localStorage instead of JSON files.

---

## 🔑 Default Login

| Username | Password   | Role  |
|----------|-----------|-------|
| admin    | admin123  | Admin |
| user1    | user123   | User  |

---

## ✨ Features

- 🌙 **5 Color Themes** — Gold, Galaxy, Fire, Ocean, Forest
- 🏪 **Custom Shop Name & Tagline**
- 💾 **JSON File Database** — items.json, utang.json, users.json, settings.json
- 📋 **Utang Tracker** — Admin adds, users view their own
- 🛒 **Shop** — Browse items with search & category filter
- 👤 **Per Person Summary** — Group utang by person, see total balance
- 🧾 **Print Receipt** — Per record or per person summary
- 📱 **Mobile Friendly** — Bottom navigation, sidebar, touch optimized
- 🔌 **Offline Fallback** — Works without server using localStorage

---

## 🗄️ Database Files

All data is stored as readable JSON files in the `data/` folder:

- **items.json** — Shop items (name, price, stock, category, emoji)
- **utang.json** — Credit records (name, items, amount, account, status, date)
- **users.json** — User accounts (username, password, role)
- **settings.json** — Shop name, tagline, theme, auto-increment IDs

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST   | /api/login | Login |
| GET    | /api/items | Get all items |
| POST   | /api/items | Add item |
| PUT    | /api/items/:id | Update item |
| DELETE | /api/items/:id | Delete item |
| GET    | /api/utang | Get utang (filterable) |
| POST   | /api/utang | Add utang record |
| PUT    | /api/utang/:id | Update record |
| DELETE | /api/utang/:id | Delete record |
| PUT    | /api/utang/person/:name/paid | Mark all paid for person |
| GET    | /api/users | Get all users |
| POST   | /api/users | Create user |
| DELETE | /api/users/:id | Delete user |
| GET    | /api/settings | Get settings |
| PUT    | /api/settings | Update settings |
| GET    | /api/stats | Get dashboard stats |
